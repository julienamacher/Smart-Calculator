package xmlhelper;

import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 * This class contains all helper functions related to XML
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class XMLHelper {

    /**
     * @param node XML node to consider
     * @return a HashMap<ChildName, Node> of all the children of the supplied node
     */
    
    public static HashMap<String, Node> getChildren(Node node) {
        HashMap<String, Node> ret = new HashMap<>();
        NodeList nodeList = node.getChildNodes();

        int len = nodeList.getLength();
        for (int i = 0; i < len; i++) {
            Node currentNode = nodeList.item(i);
            ret.put(currentNode.getNodeName(), currentNode);
        }

        return ret;
    }
    
    /**
     * @return a document builder from the document factory
     */

    public static DocumentBuilder getDocumentBuilder() {
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = null;

        try {
            docBuilder = docFactory.newDocumentBuilder();
        } catch (ParserConfigurationException ex) {
        }

        return docBuilder;
    }
    
    /**
     * @param xml XML String to convert to a XML Document
     * @return a XML document
     * @throws java.lang.Exception in case the supplied XML string is not a XML document
     */

    public static Document parseXMLFromString(String xml) throws Exception {
        DocumentBuilder builder = XMLHelper.getDocumentBuilder();

        InputSource is = new InputSource(new StringReader(xml));
        return builder.parse(is);
    }

    /**
     * @return an empty XML 1.0 standalone document
     */
    
    public static Document createBaseDocument() {
        DocumentBuilder docBuilder = XMLHelper.getDocumentBuilder();

        Document doc = docBuilder.newDocument();
        doc.setXmlStandalone(true);
        doc.setXmlVersion("1.0");

        return doc;
    }

    /**
     * @param xmlDoc XML document to convert to String
     * @param encoding encoding to produce
     * @return a formatted String which is a representation of the XML Document
     * @throws javax.xml.transform.TransformerConfigurationException in case the document cannot be converted
     */
    
    public static String prettyPrintXML(Document xmlDoc, String encoding) throws TransformerConfigurationException, TransformerException {
        Transformer tf = TransformerFactory.newInstance().newTransformer();

        tf.setOutputProperty(OutputKeys.ENCODING, encoding);
        tf.setOutputProperty(OutputKeys.INDENT, "yes");
        tf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

        Writer stringWriter = new StringWriter();
        tf.transform(new DOMSource(xmlDoc), new StreamResult(stringWriter));

        return stringWriter.toString();
    }
}
