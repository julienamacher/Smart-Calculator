package ch.heigvd.res.toolkit.interfaces;

/**
 *
 * @author Olivier Liechti
 */
public interface IEventType {
	
}
