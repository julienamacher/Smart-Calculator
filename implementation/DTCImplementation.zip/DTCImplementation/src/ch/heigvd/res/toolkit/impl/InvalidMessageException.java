package ch.heigvd.res.toolkit.impl;

/**
 *
 * @author Olivier Liechti
 */
public class InvalidMessageException extends Exception {


}
