package typescheck;

/**
 * This class is used to check the supplied Type and verify it can be casted to a list of characters
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class CheckIsListOfCharacters implements ICheckType {

    @Override
    public boolean isTypeCorrect(String valueToTest) {
        String[] allValues = valueToTest.split(" ");

        for (int i = 0; i < allValues.length; ++i)
        {
            if (!new CheckIsCharacter().isTypeCorrect(allValues[i]))
                return false;
        }
        
        return true;
    }
}
