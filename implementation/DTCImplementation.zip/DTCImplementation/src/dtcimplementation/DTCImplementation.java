package dtcimplementation;

import dtc.protocol.impl.beaconing.Beaconing;
import dtc.protocol.auth.DTCAuthenticator;
import dtc.services.*;
import ch.heigvd.res.toolkit.interfaces.IProtocolSerializer;
import dtc.protocol.impl.*;
import java.io.File;
import java.util.ArrayList;

/**
 * This class only defines the main() method to start a server. The server uses
 * the components that deal with protocol-specific issues at different layers
 * (transport layer, syntactic layer, semantic layer).
 *
 * @author Olivier Liechti
 */
public class DTCImplementation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        // All available services
        ArrayList<Service> allServices = new ArrayList<>();
        allServices.add(new AddService());
        allServices.add(new MinService());
        allServices.add(new MultService());
        allServices.add(new SinService());
        allServices.add(new SumService());
        allServices.add(new ToUppercaseService());

        String folderAuthenticationData = null;
        boolean requiresAuth;
        String serverName;

        if (args.length < 3) {
            System.out.println("Usage: <serverName> (-auth-dir=<authDir>) <serviceName1> <serviceName2> ... <serviceNameN>");
            System.exit(1);
        }

        serverName = args[0];

        if (serverName.length() > 10) {
            System.out.println("Server name is too long");
            System.exit(1);
        }

        requiresAuth = args[1].startsWith("-auth-dir=");

        if (requiresAuth) {
            folderAuthenticationData = args[1].substring(10);

            File f = new File(new File(System.getProperty("user.dir")), folderAuthenticationData);

            if (!f.exists() || !f.isDirectory()) {
                System.out.println("Auth dir does not exist or is not a directory");
                System.exit(1);
            }

            folderAuthenticationData = f.getAbsolutePath();
        }

        boolean allOK = true;

        for (int a = (requiresAuth ? 2 : 1); a < args.length; ++a) {
            boolean found = false;

            for (Service service : allServices) {
                if (service.getName().equals(args[a])) {
                    found = true;

                    if (ServicesPool.serviceExists(args[a])) {
                        System.out.println("Cannot add " + args[a] + " to ServicesPool : already present");
                    } else {
                        ServicesPool.addService(service);
                        System.out.println("Service " + args[a] + " added to ServicesPool");
                    }

                    break;
                }
            }

            if (!found) {
                System.out.println("Service " + args[a] + " does not exist");
                allOK = false;
            }
        }

        if (!allOK) {
            System.out.println("Cannot continue");
            System.exit(1);
        }

        //System.setProperty("java.util.logging.SimpleFormatter.format", "%2$s %n---> %5$s %n %n");
        System.setProperty("java.util.logging.SimpleFormatter.format", "%5$s %n");

        // We will use a particular communication interface to interact with peers.
        // (the inteface may rely on TCP, UDP but maybe also on HTTP, E-MAIL, etc.)
        DTCOnTCPInterfaceController interfaceController = new DTCOnTCPInterfaceController(DTCProtocol.DEFAULT_PORT);

        // We will exchange "raw" serialized data on an interface. Therefore, we need 
        // a class to take care of the serialization/deserialization of this raw data
        // from/into application-level messages
        IProtocolSerializer protocolSerializer = new DTCProtocolSerializer();

        // We use a protocol to communicate with other parties. We need a class to
        // be responsible for the semantics of the protocol (the class knows what
        // needs to be done when certain messages are received via a communication
        // interface
        DTCProtocolHandler protocolHandler = new DTCProtocolHandler(protocolSerializer);

        // We need the inteface controller to be connected to the protocol handler,
        // so that messages arriving on the communication interface can be processed
        // by the protocol handler, and so that the results produced by the protocol
        // handler can be sent back via the interface controller
        interfaceController.registerProcotolHandler(protocolHandler);

        if (requiresAuth) {
            DTCAuthenticator.setRequiresAuthentication(folderAuthenticationData);
        }

        if (requiresAuth) {
            System.out.println("Server will require users to authenticate");
            System.out.println("Auth dir : " + folderAuthenticationData);
        } else {
            System.out.println("Server is open, no account required");
        }

        Beaconing beacon = new Beaconing(DTCProtocol.BEACON_PORT, 1, serverName, requiresAuth);

        // We are ready, so let us start the interface controller and accept incoming
        // messages
        interfaceController.startup();
    }

}
