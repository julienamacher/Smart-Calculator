package dtc.protocol.auth;

import dtc.protocol.messages.DTCClientRequestHelper;
import dtc.protocol.messages.DTCClientRequest_Connect;
import dtc.protocol.messages.DTCClientRequest_Registration;
import dtc.protocol.messages.Response;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/**
 * This class represents the authenticator used to authenticate users who want to connect to the server
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class DTCAuthenticator {

    private static boolean requiresAuthentication = false;
    private static String accountStorageFolder = null;
    private static final Pattern rgxCheckUserIdFormat = Pattern.compile("^[a-zA-Z0-9_-]+$");

    public static String getAccountStorageFolder() {
        return accountStorageFolder;
    }

    public static boolean isAuthenticationMandatory() {
        return requiresAuthentication;
    }

    public static void setRequiresAuthentication(String accountStorageFolder) {
        DTCAuthenticator.requiresAuthentication = true;
        DTCAuthenticator.accountStorageFolder = accountStorageFolder;
    }

    public static synchronized AuthenticationResult authenticate(DTCClientRequest_Connect connectMessage) {
        String userId = connectMessage.getUserId();
        String password = connectMessage.getPassword();
        boolean connectedOrAuthenticated = false;
        Response response;

        if (!requiresAuthentication) {
            if (userId != null || password != null) {
                response = DTCClientRequestHelper.BuildResponse_Connect(DTCClientRequestHelper.CONNECT_STATE.AUTHENTICATION_ERROR, DTCClientRequestHelper.CONNECT_ERROR_CODES.SERVER_DOES_NOT_REQUIRE_AUTHENTICATION);
            } else {
                connectedOrAuthenticated = true;
                response = DTCClientRequestHelper.BuildResponse_Connect(DTCClientRequestHelper.CONNECT_STATE.CONNECTED, null);
            }
        } else {
            if (userId == null || password == null) {
                response = DTCClientRequestHelper.BuildResponse_Connect(DTCClientRequestHelper.CONNECT_STATE.AUTHENTICATION_ERROR, DTCClientRequestHelper.CONNECT_ERROR_CODES.USER_ID_OR_PASSWORD_MISSING);
            } else {
                File pathToUserAccountRequested = new File(accountStorageFolder, userId);

                if (userId.isEmpty() || !pathToUserAccountRequested.exists() || !DTCAuthenticator.rgxCheckUserIdFormat.matcher(userId).find()) {
                    response = DTCClientRequestHelper.BuildResponse_Connect(DTCClientRequestHelper.CONNECT_STATE.AUTHENTICATION_ERROR, DTCClientRequestHelper.CONNECT_ERROR_CODES.UNKNOWN_USER_ID);
                } else {
                    String realSHA1Password = null;
                    boolean passwordRead = false;

                    try {
                        byte[] encoded = Files.readAllBytes(Paths.get(pathToUserAccountRequested.getPath()));
                        realSHA1Password = new String(encoded, "UTF-8");
                        passwordRead = true;
                    } catch (IOException ex) {
                        Logger.getLogger(DTCAuthenticator.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    try {
                        String sha1PasswordReceived = DTCAuthenticator.hashSHA1(userId, password);

                        if (passwordRead && sha1PasswordReceived.equals(realSHA1Password)) {
                            connectedOrAuthenticated = true;
                            response = DTCClientRequestHelper.BuildResponse_Connect(DTCClientRequestHelper.CONNECT_STATE.AUTHENTICATED, null);
                        } else {
                            response = DTCClientRequestHelper.BuildResponse_Connect(DTCClientRequestHelper.CONNECT_STATE.AUTHENTICATION_ERROR, DTCClientRequestHelper.CONNECT_ERROR_CODES.INVALID_PASSWORD);
                        }
                    } catch (NoSuchAlgorithmException ex) {
                        response = DTCClientRequestHelper.BuildResponse_Connect(DTCClientRequestHelper.CONNECT_STATE.INTERNAL_ERROR, DTCClientRequestHelper.CONNECT_ERROR_CODES.INVALID_PASSWORD);
                    }
                }
            }
        }

        return new AuthenticationResult(response, connectedOrAuthenticated);
    }

    public static String hashSHA1(String username, String password) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-1");

        Formatter f = new Formatter();

        try {
            for (byte bt : md.digest((username + password).getBytes("UTF-8"))) {
                f.format("%02x", bt);
            }
        } catch (UnsupportedEncodingException ex) {
        }

        return f.toString();
    }

    public static synchronized Response createAccount(DTCClientRequest_Registration registrationMessage) {

        Response response;

        if (!requiresAuthentication) {
            // Server does not require authentication but the client wants to register
            // This is considered as an error, account creation is disabled when
            // authentication is not required
            response = DTCClientRequestHelper.BuildResponse_Register(DTCClientRequestHelper.SUCCESS_FAILURE.FAILURE, DTCClientRequestHelper.REGISTRATION_ERROR_CODES.SERVER_DOES_NOT_REQUIRE_AUTHENTICATION, registrationMessage.getNonce());
        } else {
            String userId = registrationMessage.getUserId();
            String password = registrationMessage.getPassword();

            // Client id must not contain special chars which could be used to access
            // files outside the account storage location
            if (!DTCAuthenticator.rgxCheckUserIdFormat.matcher(userId).find()) {
                response = DTCClientRequestHelper.BuildResponse_Register(DTCClientRequestHelper.SUCCESS_FAILURE.FAILURE, DTCClientRequestHelper.REGISTRATION_ERROR_CODES.USER_ID_INVALID, registrationMessage.getNonce());
            } else {

                int userIdLen = userId.length();

                // Cheking the min and max length of the user id
                if (userIdLen > 30 || userIdLen < 6) {
                    response = DTCClientRequestHelper.BuildResponse_Register(DTCClientRequestHelper.SUCCESS_FAILURE.FAILURE, DTCClientRequestHelper.REGISTRATION_ERROR_CODES.USER_ID_TOO_LONG_OR_TOO_SHORT, registrationMessage.getNonce());
                } else {

                    File pathToUserAccountRequested = new File(accountStorageFolder, userId);

                    if (pathToUserAccountRequested.exists()) {
                        // user already exists
                        response = DTCClientRequestHelper.BuildResponse_Register(DTCClientRequestHelper.SUCCESS_FAILURE.FAILURE, DTCClientRequestHelper.REGISTRATION_ERROR_CODES.USER_EXISTS, registrationMessage.getNonce());
                    } else {
                        // checking minimal password requirements
                        if (password.length() < 6) {
                            response = DTCClientRequestHelper.BuildResponse_Register(DTCClientRequestHelper.SUCCESS_FAILURE.FAILURE, DTCClientRequestHelper.REGISTRATION_ERROR_CODES.PASSWORD_IS_TOO_SHORT, registrationMessage.getNonce());
                        } else {

                            boolean internalError = false;

                            // Try to create the flat user account file
                            try {
                                pathToUserAccountRequested.createNewFile();
                            } catch (IOException ex) {
                                internalError = true;
                            }

                            if (!internalError) {
                                PrintWriter out = null;

                                try {
                                    out = new PrintWriter(pathToUserAccountRequested, "UTF-8");

                                    // Writing the hashed user password into his account flat file
                                    out.print(DTCAuthenticator.hashSHA1(userId, password));
                                } catch (FileNotFoundException | UnsupportedEncodingException | NoSuchAlgorithmException ex) {
                                    internalError = true;
                                    
                                    // In case of error we have to delete the file
                                    // otherwise the client will never be able to
                                    // authenticate or create a new account with the same username
                                    // Usual failures include invalid platform-specific naming
                                    // See for example http://msdn.microsoft.com/en-us/library/windows/desktop/aa365247%28v=vs.85%29.aspx
                                    pathToUserAccountRequested.delete();
                                } finally {
                                    if (out != null) {
                                        out.close();
                                    }
                                }
                            }

                            if (!internalError) {
                                response = DTCClientRequestHelper.BuildResponse_Register(DTCClientRequestHelper.SUCCESS_FAILURE.SUCCESS, null, registrationMessage.getNonce());
                            } else {
                                response = DTCClientRequestHelper.BuildResponse_Register(DTCClientRequestHelper.SUCCESS_FAILURE.FAILURE, DTCClientRequestHelper.REGISTRATION_ERROR_CODES.INTERNAL_ERROR, registrationMessage.getNonce());
                            }
                        }
                    }
                }
            }
        }

        return response;
    }
}
