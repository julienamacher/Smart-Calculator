
package dtc.protocol.auth;

import dtc.protocol.messages.Response;

/**
 * This class represents an authentication result
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class AuthenticationResult {
    private final Response response;
    private final boolean isAuthenticatedOrConnected;

    public AuthenticationResult(Response response, boolean isAuthenticatedOrConnected) {
        this.response = response;
        this.isAuthenticatedOrConnected = isAuthenticatedOrConnected;
    }

    public Response getResponse() {
        return response;
    }

    public boolean isAuthenticatedOrConnected() {
        return isAuthenticatedOrConnected;
    }
    
}
