package dtc.protocol.messages;

import dtc.services.InvalidParametersOrderException;
import dtc.services.Service;
import dtc.services.ServiceParameter;
import dtc.messages.DTCMessageNode;
import java.util.HashMap;
import java.util.HashSet;

/**
 * This class represents all helper functions used to create high level request messages to be sent to the client
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class DTCClientRequestHelper {

    public enum SUCCESS_FAILURE {

        SUCCESS, FAILURE
    }

    public enum CONNECT_STATE {

        AUTHENTICATED, CONNECTED, AUTHENTICATION_ERROR, CONNECTION_ERROR, INTERNAL_ERROR
    }

    public enum CONNECT_ERROR_CODES {

        USER_ID_OR_PASSWORD_MISSING,
        SERVER_DOES_NOT_REQUIRE_AUTHENTICATION,
        AUTHENTICATION_DISABLED,
        UNKNOWN_USER_ID,
        INVALID_PASSWORD,
        INTERNAL_ERROR
    }

    public enum CONSUMESERVICE_ERROR_CODES {

        AUTHENTICATION_IS_REQUIRED,
        INVALID_SERVICE_NAME,
        SERVICE_IS_UNAVAILABLE,
        ARGUMENTS_MISSING,
        TOO_MANY_ARGUMENTS_PROVIDED,
        INVALID_PARAMETERS_TYPE
    }

    public enum REGISTRATION_ERROR_CODES {

        SERVER_DOES_NOT_REQUIRE_AUTHENTICATION,
        USER_ID_INVALID,
        USER_ID_TOO_LONG_OR_TOO_SHORT,
        PASSWORD_IS_TOO_SHORT,
        PASSWORD_INVALID,
        USER_EXISTS,
        INTERNAL_ERROR
    }

    public enum LISTSERVICES_ERROR_CODES {

        AUTHENTICATION_REQUIRED,
    }

    public static DTCMessageNode buildErrorNode(int errorCode, String errorDescr) {
        DTCMessageNode error = new DTCMessageNode("error");
        DTCMessageNode code = new DTCMessageNode("code");
        DTCMessageNode description = new DTCMessageNode("description");

        code.SetNodeValue(Integer.toString(errorCode));
        description.SetNodeValue(errorDescr);

        error.SetNodeValue("error");
        error.AddChild(code);
        error.AddChild(description);

        return error;
    }

    public static Response BuildResponse_Connect(CONNECT_STATE state, CONNECT_ERROR_CODES error) {

        DTCMessageNode request = new DTCMessageNode("response");
        request.AddAttribute("type", "connect");
        request.AddAttribute("protocol", "1.0");

        DTCMessageNode result = new DTCMessageNode("result");

        switch (state) {
            case AUTHENTICATED:
                result.SetNodeValue("authenticated");
                break;

            case CONNECTED:
                result.SetNodeValue("connected");
                break;

            case AUTHENTICATION_ERROR:
                result.SetNodeValue("authentication_error");
                break;

            case CONNECTION_ERROR:
                result.SetNodeValue("connection_error");
                break;
        }

        if (state == CONNECT_STATE.AUTHENTICATION_ERROR || state == CONNECT_STATE.CONNECTION_ERROR) {
            DTCMessageNode errNode = buildErrorNode(error.ordinal() + 1, error.name());

            request.AddChild(errNode);
        }

        request.AddChild(result);

        return new Response(request);
    }

    public static Response BuildResponse_ConsumeService(SUCCESS_FAILURE state, CONSUMESERVICE_ERROR_CODES error, String nonceSentByClient, String result) {
        DTCMessageNode request = new DTCMessageNode("response");
        request.AddAttribute("type", "consumeService");
        request.AddAttribute("protocol", "1.0");

        DTCMessageNode nonce = new DTCMessageNode("nonce");
        nonce.SetNodeValue(nonceSentByClient);

        DTCMessageNode resultNode = new DTCMessageNode("result");

        if (state == SUCCESS_FAILURE.SUCCESS) {
            resultNode.AddAttribute("success", "true");
            
            DTCMessageNode valueNode = new DTCMessageNode("value");
            valueNode.SetNodeValue(result);
            
            resultNode.AddChild(valueNode);
        } else {
            resultNode.AddAttribute("success", "false");
            resultNode.AddChild(DTCClientRequestHelper.buildErrorNode(error.ordinal() + 1, error.name()));
        }

        request.AddChild(nonce);
        request.AddChild(resultNode);

        return new Response(request);
    }

    public static Response BuildResponse_Register(SUCCESS_FAILURE state, REGISTRATION_ERROR_CODES error, String nonceSentByClient) {

        DTCMessageNode request = new DTCMessageNode("response");
        request.AddAttribute("type", "registration");
        request.AddAttribute("protocol", "1.0");

        DTCMessageNode nonce = new DTCMessageNode("nonce");
        nonce.SetNodeValue(nonceSentByClient);

        DTCMessageNode result = new DTCMessageNode("result");

        if (state == SUCCESS_FAILURE.SUCCESS) {
            result.AddAttribute("type", "success");
        } else {
            result.AddAttribute("type", "error");
            result.AddChild(DTCClientRequestHelper.buildErrorNode(error.ordinal() + 1, error.name()));
        }

        request.AddChild(nonce);
        request.AddChild(result);

        return new Response(request);
    }


    public static Response BuildRequest_ListServices(SUCCESS_FAILURE state, LISTSERVICES_ERROR_CODES error, HashSet<Service> services) throws InvalidParametersOrderException {
        DTCMessageNode request = new DTCMessageNode("response");
        request.AddAttribute("type", "listServices");
        request.AddAttribute("protocol", "1.0");
        
        DTCMessageNode resultNode = new DTCMessageNode("result");

        if (state == SUCCESS_FAILURE.SUCCESS) {
            
            resultNode.AddAttribute("success", "true");
            
            DTCMessageNode allServices = new DTCMessageNode("services");

            for (Service service : services) {
                DTCMessageNode serviceNode = new DTCMessageNode("service");
                DTCMessageNode serviceNameNode = new DTCMessageNode("name");

                serviceNameNode.SetNodeValue(service.getName());

                DTCMessageNode serviceDescrNode = new DTCMessageNode("description");
                serviceDescrNode.SetNodeValue(service.getDescription());

                DTCMessageNode parametersNode = new DTCMessageNode("parameters");

                HashMap<Integer, ServiceParameter> parameters = service.getParameters();
                int parametersCount = parameters.size();

                for (int i = 0; i < parametersCount; ++i) {
                    if (!parameters.containsKey(i)) {
                        throw new InvalidParametersOrderException();
                    }
                    
                    ServiceParameter parameter = parameters.get(i);
                    
                    DTCMessageNode currentParameterNode = new DTCMessageNode("parameter");
                    currentParameterNode.AddAttribute("order", Integer.toString(i + 1));
                    
                    DTCMessageNode currentParameterTypeNode = new DTCMessageNode("type");
                    currentParameterTypeNode.SetNodeValue(parameter.getType().name().toLowerCase());
                    
                    DTCMessageNode currentParameterDescrNode = new DTCMessageNode("description");
                    currentParameterDescrNode.SetNodeValue(parameter.getDescription());
                    
                    currentParameterNode.AddChild(currentParameterTypeNode);
                    currentParameterNode.AddChild(currentParameterDescrNode);
                    
                    parametersNode.AddChild(currentParameterNode);
                }
                
                DTCMessageNode returnsNode = new DTCMessageNode("returns");
                DTCMessageNode returnsTypeNode = new DTCMessageNode("type");
                DTCMessageNode returnsDescriptionNode = new DTCMessageNode("description");
                
                returnsTypeNode.SetNodeValue(service.getReturns().getType().name().toLowerCase());
                returnsDescriptionNode.SetNodeValue(service.getReturns().getDescription());

                returnsNode.AddChild(returnsTypeNode);
                returnsNode.AddChild(returnsDescriptionNode);
                
                serviceNode.AddChild(serviceNameNode);
                serviceNode.AddChild(serviceDescrNode);
                serviceNode.AddChild(parametersNode);
                serviceNode.AddChild(returnsNode);

                allServices.AddChild(serviceNode);
            }

            resultNode.AddChild(allServices);
        }
        else
        {
            resultNode.AddAttribute("success", "false");
            resultNode.AddChild(DTCClientRequestHelper.buildErrorNode(error.ordinal() + 1, error.name()));
        }
        
        request.AddChild(resultNode);

        return new Response(request);
    }

}
