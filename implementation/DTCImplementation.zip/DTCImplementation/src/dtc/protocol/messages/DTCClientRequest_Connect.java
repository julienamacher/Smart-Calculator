package dtc.protocol.messages;

import dtc.messages.DTCMessageNode;
import dtc.protocol.impl.InvalidMessageFormatException;

/**
 * This class represents the received Connect message from a client
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class DTCClientRequest_Connect extends ClientResponse {

    private final String userId;
    private final String password;

    public String getUserId() {
        return userId;
    }

    public String getPassword() {
        return password;
    }
         
    
    public DTCClientRequest_Connect(String messageType, String userId, String password) {
        super(messageType);
        this.userId = userId;
        this.password = password;
    }
    
    public static DTCClientRequest_Connect parse(DTCMessageNode response) throws InvalidMessageFormatException
    {
        ClientResponse.Parse(response, "connect");
        
 
        DTCMessageNode credentials = response.GetNodeByName("credentials");
        String userId = null;
        String password = null;
        
        if (credentials != null)
        {
            userId = credentials.GetNodeByName("user_id").GetNodeValue();
            password = credentials.GetNodeByName("password").GetNodeValue();
        }
        
        return new DTCClientRequest_Connect("connect", userId, password);
    }
    
}
