package dtc.protocol.messages;

import dtc.messages.DTCMessageNode;
import dtc.protocol.impl.InvalidMessageFormatException;

/**
 * This class represents the received List Services message from a client
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class DTCClientRequest_ListServices extends ClientResponse {
    public DTCClientRequest_ListServices(String messageType) {
        super(messageType);
    }
    
    public static DTCClientRequest_ListServices parse(DTCMessageNode response) throws InvalidMessageFormatException
    {
        ClientResponse.Parse(response, "listServices");
        
        return new DTCClientRequest_ListServices("listServices");
    }
    
}
