package dtc.protocol.messages;

import dtc.messages.DTCMessageNode;
import dtc.protocol.impl.InvalidMessageFormatException;

/**
 * This class represents the received Registration message from a client
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class DTCClientRequest_Registration extends ClientResponse {

    private final String nonce;
    private final String userId;
    private final String password;

    public String getNonce() {
        return this.nonce;
    }

    public String getUserId() {
        return this.userId;
    }

    public String getPassword() {
        return this.password;
    }
            
    
    public DTCClientRequest_Registration(String messageType, String nonce, String userId, String password) {
        super(messageType);
        this.nonce = nonce;
        this.userId = userId;
        this.password = password;
    }
    
    public static DTCClientRequest_Registration parse(DTCMessageNode response) throws InvalidMessageFormatException
    {
        ClientResponse.Parse(response, "registration");

        String nonce = response.GetNodeByName("nonce").GetNodeValue();
        String userId = response.GetNodeByName("user_id").GetNodeValue();
        String password = response.GetNodeByName("password").GetNodeValue();
        
        return new DTCClientRequest_Registration("registration", nonce, userId, password);
    }
    
}
