package dtc.protocol.messages;

import dtc.messages.DTCMessageNode;
import dtc.protocol.impl.InvalidMessageFormatException;
import java.util.HashMap;

/**
 * This class represents the received Service Consumption message from a client
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class DTCClientRequest_ConsumeService extends ClientResponse {
    
    private final String nonce;
    private final String serviceName;
    private final HashMap<Integer, String> parameters;

    public DTCClientRequest_ConsumeService(String messageType, String nonce, String serviceName, HashMap<Integer, String> parameters) {
        super(messageType);
        this.nonce = nonce;
        this.serviceName = serviceName;
        this.parameters = parameters;
    }

    public String getNonce() {
        return nonce;
    }

    public String getServiceName() {
        return serviceName;
    }

    public HashMap<Integer, String> getParameters() {
        return parameters;
    }

    
    public static DTCClientRequest_ConsumeService parse(DTCMessageNode response) throws InvalidMessageFormatException
    {
        ClientResponse.Parse(response, "consumeService");

        String nonce = response.GetNodeByName("nonce").GetNodeValue();
        String serviceName = response.GetNodeByName("name").GetNodeValue();;
        HashMap<Integer, String> parameters = new HashMap<>();
        
        int maxParameterCount = 0;
        
        for (DTCMessageNode parameter : response.GetNodeByName("parameters").GetChildren())
        {
            int parameterOrder = Integer.parseInt(parameter.GetAttribute("order"));
            
            // Parameters order have to be unique
            if (parameterOrder < 1 || parameters.containsKey(parameterOrder))
                throw new InvalidMessageFormatException();
            
            if (parameterOrder > maxParameterCount)
                maxParameterCount = parameterOrder;
            
            DTCMessageNode parameterValue = parameter.GetNodeByName("value");
            
            parameters.put(parameterOrder, parameterValue.GetNodeValue());
        }
        
        // Parameters must be sequential values
        if (parameters.size() != maxParameterCount)
            throw new InvalidMessageFormatException();
        
        return new DTCClientRequest_ConsumeService("consumeService", nonce, serviceName, parameters);
    }

    
    
}