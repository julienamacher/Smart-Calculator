package dtc.protocol.messages;

import dtc.messages.DTCMessageNode;

/**
 * This class represents a response
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class Response
{
    final DTCMessageNode root;
    
    public Response(DTCMessageNode root)
    {
        this.root = root;
    }
    
    public DTCMessageNode GetRoot()
    {
        return this.root;
    }
}
