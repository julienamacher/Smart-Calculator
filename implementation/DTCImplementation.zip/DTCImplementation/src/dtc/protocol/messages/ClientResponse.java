package dtc.protocol.messages;

import dtc.messages.DTCMessageNode;
import dtc.protocol.impl.InvalidMessageFormatException;

/**
 * This class represents a client response
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public abstract class ClientResponse {
    final protected String messageType;

    public String getMessageType() {
        return messageType;
    }
    
    public ClientResponse(final String messageType)
    {
        this.messageType = messageType;
    }
    
    public static boolean CheckResponseType(DTCMessageNode response, String messageTypeCompareTo)
    {
        return response.AttributeExists("type") &&
               response.GetAttribute("type").equals(messageTypeCompareTo);
    }
    
    public static ClientResponse Parse(DTCMessageNode response, String messageTypeCompareTo) throws InvalidMessageFormatException
    {
        if (!ClientResponse.CheckResponseType(response, messageTypeCompareTo))
        {
            throw new InvalidMessageFormatException();
        }

        return null;
    }
}
