package dtc.protocol.impl;

/**
 * This class represents the exception thrown when trying to parse an invalid high-level message
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class InvalidMessageFormatException extends Exception {
}
