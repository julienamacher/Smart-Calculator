package dtc.protocol.impl;

import dtc.protocol.messages.Response;
import dtc.protocol.messages.DTCClientRequestHelper;
import dtc.protocol.messages.DTCClientRequest_Registration;
import dtc.protocol.messages.DTCClientRequest_ConsumeService;
import dtc.protocol.messages.DTCClientRequest_Connect;
import dtc.protocol.messages.DTCClientRequest_ListServices;
import dtc.protocol.auth.AuthenticationResult;
import dtc.protocol.auth.DTCAuthenticator;
import dtc.services.InvalidParametersTypeException;
import dtc.services.InvalidParametersOrderException;
import dtc.services.NotEnoughParametersException;
import dtc.services.TooManyParametersException;
import dtc.services.Service;
import ch.heigvd.res.toolkit.impl.AbstractStateMachine;
import ch.heigvd.res.toolkit.impl.Event;
import ch.heigvd.res.toolkit.impl.Message;
import ch.heigvd.res.toolkit.interfaces.IContext;
import ch.heigvd.res.toolkit.interfaces.IState;
import ch.heigvd.res.toolkit.interfaces.IStateMachine;
import dtc.messages.DTCMessage;
import dtc.messages.DTCMessageNode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This class implements the state machine for the Ping Pong protocol.
 *
 * @author Olivier Liechti
 */
public class DTCProtocolStateMachine extends AbstractStateMachine implements IStateMachine {

    final static Logger LOG = Logger.getLogger(DTCProtocolStateMachine.class.getName());
    HashMap<Long, HashMap<String, Object>> sessions = new HashMap<>();

    /**
     * This object is used to detect that the client has been inactive for too
     * long
     */
    private final InactivityGuard inactivityGuard = new InactivityGuard();

    /**
     * These three fields are part of the state for the state machine, i.e.
     * their value evolves in reaction to events and state transitions
     */
    private int successCount = 0;
    private int missedCount = 0;
    private int lateCount = 0;

    /**
     * This class detects when the client has not sent valid commands for too
     * long
     */
    private class InactivityGuard {

        private Timer timer;

        private long lastClientActivityTime;

        public void start() {
            lastClientActivityTime = System.currentTimeMillis();
            timer = new Timer();
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    Event maxIdleTimeReachedEvent = new Event(DTCProtocol.EventType.EVENT_TYPE_MAX_IDLE_TIME_REACHED);
                    DTCProtocolStateMachine.this.onEvent(maxIdleTimeReachedEvent);
                }
            }, DTCProtocol.MAX_INACTIVE_TIMEOUT, DTCProtocol.MAX_INACTIVE_TIMEOUT);
        }

        public void stop() {
            if (timer != null) {
                timer.cancel();
            }
        }

        public void notifyClientActivity() {
            if (timer != null) {
                timer.cancel();
            }
            start();
        }
    }

    public DTCProtocolStateMachine(IContext context) {
        super(context);
    }

    @Override
    public void destroy() {
        inactivityGuard.stop();
    }

    @Override
    public IState getInitialState() {
        return DTCProtocol.State.STATE_START;
    }

    @Override
    public void onStateEntered(IState state) {
        super.onStateEntered(state);

        if (state == DTCProtocol.State.STATE_START) {
            //Message msg = new Message(DTCProtocol.MessageType.MESSAGE_TYPE_NOTIFICATION);
            //msg.setAttribute("payload", DTCProtocol.NOTIFICATION_WELCOME_TEXT);
            //getContext().sendMessage(msg);
            triggerTransitionToState(DTCProtocol.State.STATE_NORMAL);
            inactivityGuard.notifyClientActivity();
        }


         //When we enter STATE_END, we send a notification to inform the client that we are
         // closing the connection. We then close the connection.
		 
         if (state == DTCProtocol.State.STATE_END) {
            inactivityGuard.stop();
            getContext().closeSession();
         }
    }

    @Override
    public void onEvent(Event e) {
        LOG.log(Level.INFO, "State Machine has received an event: {0} - {1}", new Object[]{e.getType(), e});

        
         if (e.getType() == DTCProtocol.EventType.EVENT_TYPE_MAX_IDLE_TIME_REACHED) {
            triggerTransitionToState(DTCProtocol.State.STATE_END);
            return;
         }
                
            /*    
         // If we have received an invalid message from the client we return an error message
         if (e.getType() == Event.EventType.EVENT_TYPE_INVALID_MESSAGE_ARRIVED) {
         Message reply = new Message(DTCProtocol.MessageType.MESSAGE_TYPE_RESULT);
         reply.setAttribute("statusCode", 400);
         reply.setAttribute("payload", DTCProtocol.RESULT_INVALID_CMD_TEXT);
         getContext().sendMessage(reply);
         return;
         }
         */
        // If we have received a message from the client, we have to update the last activity timestamp
        if (e.getType() == Event.EventType.EVENT_TYPE_MESSAGE_ARRIVED) {
            inactivityGuard.notifyClientActivity();
        }

        if (e.getType() == Event.EventType.EVENT_TYPE_MESSAGE_ARRIVED) {
            DTCMessage message = (DTCMessage) e.getAttribute("message");
            DTCMessageNode root = (DTCMessageNode) message.getAttribute("tree");
            String type = root.GetAttribute("type");
            long sessionId = this.getContext().getSessionId();
            
            switch (type) {
                case "registration": {

                    DTCClientRequest_Registration registrationMessage = null;

                    try {
                        registrationMessage = DTCClientRequest_Registration.parse(root);
                    } catch (InvalidMessageFormatException ex) {
                    }

                    if (registrationMessage != null) {
                        Response response = DTCAuthenticator.createAccount(registrationMessage);

                        Message lastMessage = new Message(DTCProtocol.MessageType.MESSAGE_TYPE_RESULT);
                        lastMessage.setAttribute("payload", response);

                        getContext().sendMessage(lastMessage);
                    }
                }

                break;

                case "connect": {
                    
                    DTCClientRequest_Connect connectMessage = null;
                    
                    try {
                        connectMessage = DTCClientRequest_Connect.parse(root);
                    } catch (InvalidMessageFormatException ex) {
                    }

                 
                    if (connectMessage != null)
                    {
                        
                        AuthenticationResult authResult = DTCAuthenticator.authenticate(connectMessage);
                        Response response = authResult.getResponse();

                        if (authResult.isAuthenticatedOrConnected())
                        {
                            // user can be null if authentication is disabled
                            // here we just want to create the key userId
                            
                            if (sessions.containsKey(sessionId))
                            {
                                if (sessions.get(sessionId).containsKey("userId"))
                                    sessions.get(sessionId).remove("userId");
                                    
                                sessions.get(sessionId).put("userId", connectMessage.getUserId());
                            }
                        }
                        else
                        {
                            if (sessions.containsKey(sessionId) && sessions.get(sessionId).containsKey("userId"))
                            {
                                sessions.get(sessionId).remove("userId");
                            }
                            
                        }


                        Message lastMessage = new Message(DTCProtocol.MessageType.MESSAGE_TYPE_RESULT);
                        lastMessage.setAttribute("payload", response);

                        getContext().sendMessage(lastMessage);
                    }
                    
                    break;
                }
                case "listServices": {

                    Response response = null;
                    
                    // User must be connected
                    if (!sessions.containsKey(sessionId) ||
                        !sessions.get(sessionId).containsKey("userId"))
                    {
                        try {
                            DTCClientRequest_ListServices listServicesMessage = DTCClientRequest_ListServices.parse(root);
                        } catch (InvalidMessageFormatException ex) {

                        }

                        try {
                            response = DTCClientRequestHelper.BuildRequest_ListServices(DTCClientRequestHelper.SUCCESS_FAILURE.SUCCESS, null, ServicesPool.getAllServices());
                        } catch (InvalidParametersOrderException ex) {
                        }

                    }
                    else
                    {
                        try {
                            response = DTCClientRequestHelper.BuildRequest_ListServices(DTCClientRequestHelper.SUCCESS_FAILURE.FAILURE, DTCClientRequestHelper.LISTSERVICES_ERROR_CODES.AUTHENTICATION_REQUIRED, null);
                        } catch (InvalidParametersOrderException ex) {
                        }
                    }

                    if (response != null) {
                        Message lastMessage = new Message(DTCProtocol.MessageType.MESSAGE_TYPE_RESULT);
                        lastMessage.setAttribute("payload", response);

                        getContext().sendMessage(lastMessage);
                    }
                    

                    break;
                }

                case "consumeService": {
                    
                    DTCClientRequest_ConsumeService consumeServiceMessage = null;

                    try {
                        consumeServiceMessage = DTCClientRequest_ConsumeService.parse(root);
                    } catch (InvalidMessageFormatException ex) {

                    }
                    
                    Response response = null;
                    
                    if (!sessions.containsKey(sessionId) ||
                        !sessions.get(sessionId).containsKey("userId"))
                    {
                        

                        if (!ServicesPool.isServiceRegistered(consumeServiceMessage.getServiceName())) {
                            response = DTCClientRequestHelper.BuildResponse_ConsumeService(DTCClientRequestHelper.SUCCESS_FAILURE.FAILURE, DTCClientRequestHelper.CONSUMESERVICE_ERROR_CODES.INVALID_SERVICE_NAME, null, null);
                        } else {
                            Service serviceRequested = ServicesPool.getService(consumeServiceMessage.getServiceName());

                            try {
                                String result = serviceRequested.process(new ArrayList<String>(consumeServiceMessage.getParameters().values()));

                                response = DTCClientRequestHelper.BuildResponse_ConsumeService(DTCClientRequestHelper.SUCCESS_FAILURE.SUCCESS, null, consumeServiceMessage.getNonce(), result);

                            } catch (NotEnoughParametersException ex) {
                                response = DTCClientRequestHelper.BuildResponse_ConsumeService(DTCClientRequestHelper.SUCCESS_FAILURE.FAILURE, DTCClientRequestHelper.CONSUMESERVICE_ERROR_CODES.ARGUMENTS_MISSING, consumeServiceMessage.getNonce(), null);
                            } catch (TooManyParametersException ex) {
                                response = DTCClientRequestHelper.BuildResponse_ConsumeService(DTCClientRequestHelper.SUCCESS_FAILURE.FAILURE, DTCClientRequestHelper.CONSUMESERVICE_ERROR_CODES.TOO_MANY_ARGUMENTS_PROVIDED, consumeServiceMessage.getNonce(), null);
                            } catch (InvalidParametersTypeException ex) {
                                response = DTCClientRequestHelper.BuildResponse_ConsumeService(DTCClientRequestHelper.SUCCESS_FAILURE.FAILURE, DTCClientRequestHelper.CONSUMESERVICE_ERROR_CODES.INVALID_PARAMETERS_TYPE, consumeServiceMessage.getNonce(), null);
                            }

                        }
                    }
                    else
                    {
                        response = DTCClientRequestHelper.BuildResponse_ConsumeService(DTCClientRequestHelper.SUCCESS_FAILURE.FAILURE, DTCClientRequestHelper.CONSUMESERVICE_ERROR_CODES.AUTHENTICATION_IS_REQUIRED, consumeServiceMessage.getNonce(), null);
                    }

                    Message responseMsg = new Message(DTCProtocol.MessageType.MESSAGE_TYPE_RESULT);
                    responseMsg.setAttribute("payload", response);

                    getContext().sendMessage(responseMsg);

                    break;
                }
            }
        }

        /*
         // Whatever the state, if we receive a BYE command, we know what to do
         if (e.getType() == Event.EventType.EVENT_TYPE_MESSAGE_ARRIVED) {
         Message incomingMessage = (Message) (e.getAttribute("message"));
         String command = (String) incomingMessage.getAttribute("command");
         if (DTCProtocol.Command.CMD_BYE.getKeyword().equals(command)) {
         Message lastMessage = new Message(DTCProtocol.MessageType.MESSAGE_TYPE_RESULT);
         lastMessage.setAttribute("payload", DTCProtocol.RESULT_BYE_TEXT);
         getContext().sendMessage(lastMessage);
         triggerTransitionToState(DTCProtocol.State.STATE_END);
         return;
         }
         }
                
                
         // Whatever the state, if we receive a SCORE command, we know what to do
         if (e.getType() == Event.EventType.EVENT_TYPE_MESSAGE_ARRIVED) {
         Message incomingMessage = (Message) (e.getAttribute("message"));
         String command = (String) incomingMessage.getAttribute("command");
         if (DTCProtocol.Command.CMD_SCORE.getKeyword().equals(command)) {
         Message scoreMessage = new Message(DTCProtocol.MessageType.MESSAGE_TYPE_RESULT);
         StringBuilder scoreMessagePayload = new StringBuilder();
         scoreMessagePayload.append("Missed: ")
         .append(missedCount)
         .append(" Successful: ")
         .append(successCount)
         .append(" Late: ")
         .append(lateCount);

         scoreMessage.setAttribute("statusCode", "200");
         scoreMessage.setAttribute("payload", scoreMessagePayload.toString());
         getContext().sendMessage(scoreMessage);
         return;
         }
         }

         // Whatever the state, if we receive a HELP command, we know what to do
         if (e.getType() == Event.EventType.EVENT_TYPE_MESSAGE_ARRIVED) {
         Message incomingMessage = (Message) (e.getAttribute("message"));
         String command = (String) incomingMessage.getAttribute("command");
         if (DTCProtocol.Command.CMD_HELP.getKeyword().equals(command)) {
         Message message = new Message(DTCProtocol.MessageType.MESSAGE_TYPE_RESULT);

         StringBuilder helpMessagePayload = new StringBuilder("You can use the following commands: ");
         for (DTCProtocol.Command cmd : DTCProtocol.Command.values()) {
         helpMessagePayload.append("['")
         .append(cmd.getKeyword())
         .append("': ")
         .append(cmd.getHelp())
         .append("] ");
         }
         message.setAttribute("statusCode", "200");
         message.setAttribute("payload", helpMessagePayload.toString());
         getContext().sendMessage(message);
         return;
         }
         }

         switch ((DTCProtocol.State) getCurrentState()) {
         //case STATE_PING:
         //	onEventInStatePingOrPong(e);
         //	break;
         case STATE_NORMAL:
         onEventInStatePingOrPong(e);
         break;
         }
         */
    }
}
