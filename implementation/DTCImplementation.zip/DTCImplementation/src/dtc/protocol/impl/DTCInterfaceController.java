package dtc.protocol.impl;

import ch.heigvd.res.toolkit.impl.TcpLineInterfaceController;
import java.util.logging.Logger;

public class DTCInterfaceController extends TcpLineInterfaceController {

    final static Logger LOG = Logger.getLogger(DTCInterfaceController.class.getName());

    public DTCInterfaceController(int port) {
        super(port);
    }
}
