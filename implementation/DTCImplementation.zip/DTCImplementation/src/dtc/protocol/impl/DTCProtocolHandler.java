package dtc.protocol.impl;

import ch.heigvd.res.toolkit.impl.AbstractProtocolHandler;
import ch.heigvd.res.toolkit.interfaces.IContext;
import ch.heigvd.res.toolkit.interfaces.IProtocolSerializer;
import ch.heigvd.res.toolkit.interfaces.IStateMachine;
import java.util.logging.Logger;

/**
 *
 * @author Olivier Liechti
 */
public class DTCProtocolHandler extends AbstractProtocolHandler {

    final static Logger LOG = Logger.getLogger(DTCProtocolHandler.class.getName());

    public DTCProtocolHandler(IProtocolSerializer protocolSerializer) {
        super(protocolSerializer);
    }

    @Override
    public IStateMachine getProtocolStateMachine(IContext context) {
        return new DTCProtocolStateMachine(context);
    }
}
