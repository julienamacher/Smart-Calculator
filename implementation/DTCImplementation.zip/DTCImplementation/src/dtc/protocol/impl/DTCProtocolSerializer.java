package dtc.protocol.impl;

import dtc.protocol.messages.Response;
import ch.heigvd.res.toolkit.impl.Message;
import ch.heigvd.res.toolkit.interfaces.IProtocolSerializer;
import dtc.messages.DTCMessage;
import dtc.messages.DTCMessageHelper;
import dtc.messages.DTCMessageNode;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import org.w3c.dom.Document;
import xmlhelper.XMLHelper;

/**
 * This class handles the serialization/deserialization process for the Ping
 * Pong protocol. This is where we implement syntax-level considerations defined
 * in the Ping Pong protocol specification.
 *
 * @author Olivier Liechti
 */
public class DTCProtocolSerializer implements IProtocolSerializer {

    final static Logger LOG = Logger.getLogger(DTCProtocolSerializer.class.getName());

    @Override
    public DTCMessage deserialize(byte[] data) {
        LOG.info("Deserializing transport-level data into application-level message");
        DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder domBuilder = null;
        
        try {
            domBuilder = domFactory.newDocumentBuilder();
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(DTCMessageHelper.class.getName()).log(Level.SEVERE, null, ex);
        }

        String request = null;

        try {
            request = new String(data, "UTF-8");
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(DTCProtocolSerializer.class.getName()).log(Level.SEVERE, null, ex);
        }

        Document document = null;

        try {
            document = XMLHelper.parseXMLFromString(request);
        } catch (Exception ex) {
            Logger.getLogger(DTCProtocolSerializer.class.getName()).log(Level.SEVERE, null, ex);
        }

        DTCMessageNode message = null;

        try {
            message = DTCMessageHelper.XMLDocumentToDTCMessage(DTCProtocol.MessageType.MESSAGE_TYPE_COMMAND, document);
        } catch (MalformedHierarchyForXMLFormat ex) {
            Logger.getLogger(DTCProtocolSerializer.class.getName()).log(Level.SEVERE, null, ex);
        }

        return new DTCMessage(DTCProtocol.MessageType.MESSAGE_TYPE_COMMAND, message);
    }

    @Override
    public byte[] serialize(Message message) {
        LOG.info("Serializing application-level message into transport-level data");

        Response response = (Response) message.getAttribute("payload");
        Document xmlDoc = null;
        String messageText = null;
        try {
            xmlDoc = DTCMessageHelper.DTCMessageToXMLDocument(DTCProtocol.MessageType.MESSAGE_TYPE_RESULT, response.GetRoot());
        } catch (MalformedHierarchyForXMLFormat ex) {
            Logger.getLogger(DTCProtocolSerializer.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            messageText = XMLHelper.prettyPrintXML(xmlDoc, "UTF-8");
        } catch (TransformerException ex) {
            Logger.getLogger(DTCProtocolSerializer.class.getName()).log(Level.SEVERE, null, ex);
        }

        byte[] data = null;
        
        try {
            data = messageText.getBytes("UTF-8");
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(DTCProtocolSerializer.class.getName()).log(Level.SEVERE, null, ex);
        }

        LOG.log(Level.INFO, "-->  From: {0}", message);
        LOG.log(Level.INFO, "-->    To: {0}", messageText);
        return data;
    }

}
