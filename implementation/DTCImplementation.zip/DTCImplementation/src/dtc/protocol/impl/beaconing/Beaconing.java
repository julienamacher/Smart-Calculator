package dtc.protocol.impl.beaconing;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import dtc.messages.*;
import dtc.protocol.impl.DTCProtocol;
import dtc.protocol.impl.MalformedHierarchyForXMLFormat;
import javax.xml.transform.TransformerException;
import xmlhelper.XMLHelper;

/**
 * This class represents an active object used to send periodic heartbeat broadcasts
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class Beaconing {

    Thread beaconing = null;

    @Override
    public void finalize() throws Throwable {
        if (beaconing != null) {
            beaconing.stop();
        }

        super.finalize();
    }

    public Beaconing(final int port, final int intervalSeconds, final String serverName, final boolean requiresAuthentication) {

        DTCMessageNode root = new DTCMessageNode("response");
        root.AddAttribute("type", "endpointsDiscovery");
        root.AddAttribute("protocol", "1.0");

        DTCMessageNode requireAuthentication = new DTCMessageNode("require_authentication");
        requireAuthentication.SetNodeValue((requiresAuthentication ? "true" : "false"));

        DTCMessageNode name = new DTCMessageNode("name");
        name.SetNodeValue(serverName);

        root.AddChild(requireAuthentication);
        root.AddChild(name);

        try {
            final String message = XMLHelper.prettyPrintXML(DTCMessageHelper.DTCMessageToXMLDocument(DTCProtocol.MessageType.MESSAGE_TYPE_RESULT, root), "UTF-8");

            this.beaconing = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        while (true) {
                            Thread.sleep(intervalSeconds * 1000);
                            sendDataToClient("255.255.255.255", port, message);
                        }
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Beaconing.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
            
            this.beaconing.start ();
            
        } catch (TransformerException | MalformedHierarchyForXMLFormat ex) {
            Logger.getLogger(Beaconing.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void sendDataToClient(String ipString, int port, String data) {
        InetAddress IPAddress = null;

        try {
            IPAddress = InetAddress.getByName(ipString);
        } catch (UnknownHostException ex) {
        }

        DatagramSocket clientSocket = null;

        try {
            clientSocket = new DatagramSocket();
        } catch (SocketException ex) {

        }

        if (clientSocket != null)
        {
            byte[] sendData = null;

            try {
                sendData = data.getBytes("UTF-8");
            } catch (UnsupportedEncodingException ex) {
            }

            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, port);

            try {
                clientSocket.send(sendPacket);
            } catch (IOException ex) {
            }

            clientSocket.close();
        }
    }

}
