package dtc.protocol.impl;

import dtc.services.Service;
import java.util.HashMap;
import java.util.HashSet;

/**
 * This class represents the directory of all services available on the server
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class ServicesPool {
    final static HashMap<String, Service> allServices = new HashMap<>();
    
    public static boolean isServiceRegistered(String name)
    {
        synchronized(ServicesPool.allServices)
        {
            return ServicesPool.allServices.containsKey(name);
        }
    }
    
    public static boolean serviceExists(String name)
    {
        synchronized(ServicesPool.allServices)
        {
            return ServicesPool.allServices.containsKey(name);
        }
    }
    
    public static Service getService(String name)
    {
        synchronized(ServicesPool.allServices)
        {
            return ServicesPool.allServices.get(name);
        }
    }
    
    public static void addService(Service service)
    {
        synchronized(ServicesPool.allServices)
        {
            ServicesPool.allServices.put(service.getName(), service);
        }
    }

    static HashSet<Service> getAllServices() {
        return new HashSet<Service>(ServicesPool.allServices.values());
    }
}
