package dtc.services;

/**
 * This class represents the exception thrown when there are too many parameters received
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class TooManyParametersException extends Exception {

    public TooManyParametersException() {
    }
    
}
