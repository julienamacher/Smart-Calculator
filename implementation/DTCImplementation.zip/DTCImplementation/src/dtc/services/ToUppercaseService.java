package dtc.services;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class represents the TOUPPERCASE service which returns the same String received, transformed in uppercase
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class ToUppercaseService extends Service {

    public ToUppercaseService() {
        super("TOUPPERCASE", "Returns the supplied text in uppercase", new ServiceParameter(DTCParameterType.STRING, "The supplied text in uppercase"));
    }

    @Override
    public String process(ArrayList<String> parameters) throws NotEnoughParametersException, TooManyParametersException, InvalidParametersTypeException {
        switch (this.checkParametersType(parameters)) {
            case OK:
                break;

            case NOT_ENOUGH_PARAMETERS:
                throw new NotEnoughParametersException();

            case TOO_MANY_PARAMETERS:
                throw new TooManyParametersException();

            case INVALID_TYPE:
                throw new InvalidParametersTypeException();
        }

        return (parameters.get(0)).toUpperCase();
    }

    @Override
    public HashMap<Integer, ServiceParameter> readParameters() {
        HashMap<Integer, ServiceParameter> parameters = new HashMap<>();
        parameters.put(0, new ServiceParameter(DTCParameterType.STRING, "The text to modify"));
        return parameters;
    }
}
