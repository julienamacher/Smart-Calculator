package dtc.services;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class represents the SUM service which adds every supplied values passed to it
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class SumService extends Service {

    public SumService() {
        super("SUM", "Sums the values", new ServiceParameter(DTCParameterType.NUMERIC, "The sum of all the values"));
    }

    @Override
    public String process(ArrayList<String> parameters) throws NotEnoughParametersException, TooManyParametersException, InvalidParametersTypeException {
        switch (this.checkParametersType(parameters)) {
            case OK:
                break;

            case NOT_ENOUGH_PARAMETERS:
                throw new NotEnoughParametersException();

            case TOO_MANY_PARAMETERS:
                throw new TooManyParametersException();

            case INVALID_TYPE:
                throw new InvalidParametersTypeException();
        }

        String[] values = ((String) parameters.get(0)).split(" ");

        double total = 0;

        for (String value : values) {
            total += Double.parseDouble(value);
        }

        return Double.toString(total);
    }

    @Override
    public HashMap<Integer, ServiceParameter> readParameters() {
        HashMap<Integer, ServiceParameter> parameters = new HashMap<>();
        parameters.put(0, new ServiceParameter(DTCParameterType.LIST_NUMERIC, "All values to add up"));

        return parameters;
    }
}
