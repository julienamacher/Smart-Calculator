package dtc.services;

/**
 * This class represents the exception thrown when the received parameters are not of the correct type
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class InvalidParametersTypeException extends Exception {

    public InvalidParametersTypeException() {
    }
    
}
