package dtc.services;

/**
 * This class represents the exception thrown when the received parameters are not correctly ordered
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class InvalidParametersOrderException extends Exception {
}
