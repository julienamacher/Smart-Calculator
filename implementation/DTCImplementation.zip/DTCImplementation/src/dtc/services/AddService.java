package dtc.services;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class represents the ADD service which can add two numbers together
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class AddService extends Service {

    @Override
    public HashMap<Integer, ServiceParameter> readParameters()
    {
        HashMap<Integer, ServiceParameter> parameters = new HashMap<>();
        parameters.put(0, new ServiceParameter(DTCParameterType.NUMERIC, "The first number"));
        parameters.put(1, new ServiceParameter(DTCParameterType.NUMERIC, "The second number"));
        return parameters;
    }

    public AddService() {
        super("ADD", "Adds two numbers", new ServiceParameter(DTCParameterType.NUMERIC, "The two values added together"));
    }

    @Override
    public String process(ArrayList<String> parameters) throws NotEnoughParametersException, TooManyParametersException, InvalidParametersTypeException {
        switch (this.checkParametersType(parameters)) {
            case OK:
                break;

            case NOT_ENOUGH_PARAMETERS:
                throw new NotEnoughParametersException();

            case TOO_MANY_PARAMETERS:
                throw new TooManyParametersException();

            case INVALID_TYPE:
                throw new InvalidParametersTypeException();
        }

        // We can safely cast the parameters, they have been checked
        double firstParam = Double.parseDouble(parameters.get(0));
        double secondParam = Double.parseDouble(parameters.get(1));

        double result = firstParam + secondParam;

        return Double.toString(result);
    }
}
