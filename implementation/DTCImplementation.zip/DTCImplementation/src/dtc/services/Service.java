package dtc.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * This class represents the base class from which every Service extends
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public abstract class Service {
    public enum PARAMETERS_CHECK { OK, NOT_ENOUGH_PARAMETERS, TOO_MANY_PARAMETERS, INVALID_TYPE }
    
    private final String name;
    private final String description;
    private final ServiceParameter returns;
    private final HashMap<Integer, ServiceParameter> parameters; // param number <=> param type

    public Service(String name, String description, ServiceParameter returns) {
        this.name = name;
        this.description = description;
        this.returns = returns;
        this.parameters = this.readParameters();
    }
    
    public abstract HashMap<Integer, ServiceParameter> readParameters();

    public PARAMETERS_CHECK checkParametersType(ArrayList<String> parameters)
    {
        int requiredCount = this.parameters.size();
        int receivedCount = parameters.size();
                
        if (receivedCount > requiredCount) {
            return PARAMETERS_CHECK.TOO_MANY_PARAMETERS;
        }
        
        if (requiredCount < receivedCount) {
            return PARAMETERS_CHECK.TOO_MANY_PARAMETERS;
        }
        
        Iterator<String> it = parameters.iterator();
        
        for (int i = 0; it.hasNext(); ++i)
        {
            String parameter = it.next();
            ServiceParameter current = this.parameters.get(i);
            
            
            if (!current.getType().isList())
            {
                if (!current.getType().getTypeCheckerPrimitive().isTypeCorrect(parameter))
                    return PARAMETERS_CHECK.INVALID_TYPE;
            }
            else
            {
                if (!current.getType().getTypeCheckerList().isTypeCorrect(parameter))
                    return PARAMETERS_CHECK.INVALID_TYPE;
            }
        }
        
        return PARAMETERS_CHECK.OK;
    }
    
    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }
    
    public ServiceParameter getReturns() {
        return returns;
    }
    
    public HashMap<Integer, ServiceParameter> getParameters() {
        return parameters;
    }
    
    public abstract String process(ArrayList<String> parameters) throws NotEnoughParametersException, TooManyParametersException, InvalidParametersTypeException;
}
