package dtc.services;

import typescheck.ICheckType;
import typescheck.*;

/**
 * This class represents all data types supported by the protocol
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public enum DTCParameterType {
    
    NUMERIC("NUMERIC", "Numeric", false, null, new CheckIsNumeric()),
    INTEGER("INTEGER", "Integer", false, null, new CheckIsInteger()),
    CHARACTER("CHARACTER", "Character", false, null, new CheckIsCharacter()),
    STRING("STRING", "String", false, null, new CheckIsString()),
    LIST_NUMERIC("LIST_NUMERIC", "List of Numerics", true, new CheckIsListOfNumerics(), new CheckIsNumeric()),
    LIST_INTEGER("LIST_INTEGER", "List of Integers", true, new CheckIsListOfIntegers(), new CheckIsInteger()),
    LIST_CHARACTER("LIST_CHARACTER", "Liste of Characters", true, new CheckIsListOfCharacters(), new CheckIsCharacter()),
    LIST_STRING("LIST_STRING", "List of Strings", true, new CheckIsListOfStrings(), new CheckIsString());
    
    private final String name;
    private final String description;
    private final boolean isList;
    private final ICheckType typeCheckerList;
    private final ICheckType typeCheckerPrimitive;

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public boolean isList() {
        return this.isList;
    }
    public ICheckType getTypeCheckerList() {
        return this.typeCheckerList;
    }

    public ICheckType getTypeCheckerPrimitive() {
        return this.typeCheckerPrimitive;
    }
    
    DTCParameterType(String name, String description, boolean isList, ICheckType typeCheckerList, ICheckType typeCheckerPrimitive) {
        this.name = name;
        this.description = description;
        this.isList = isList;
        this.typeCheckerList = typeCheckerList;
        this.typeCheckerPrimitive = typeCheckerPrimitive;
    }
}
