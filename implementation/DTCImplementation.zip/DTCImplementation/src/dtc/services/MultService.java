package dtc.services;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class represents the MULT service which multiplies two numbers together
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class MultService extends Service {

    public MultService() {
        super("MULT", "Multiplies two numbers", new ServiceParameter(DTCParameterType.NUMERIC, "The two values multiplied together"));
    }

    @Override
    public String process(ArrayList<String> parameters) throws NotEnoughParametersException, TooManyParametersException, InvalidParametersTypeException
    {
        switch (this.checkParametersType(parameters))
        {
            case OK:
                break;
                
            case NOT_ENOUGH_PARAMETERS:
                throw new NotEnoughParametersException();
                
            case TOO_MANY_PARAMETERS:
                throw new TooManyParametersException();
            
            case INVALID_TYPE:
                throw new InvalidParametersTypeException();
        }
        
        // We can safely cast
        
        double firstParam = Double.parseDouble(parameters.get(0));
        double secondParam = Double.parseDouble(parameters.get(1));
       
        double result = firstParam * secondParam;
        
        return Double.toString(result);
    }

    @Override
    public HashMap<Integer, ServiceParameter> readParameters() {
        HashMap<Integer, ServiceParameter> parameters = new HashMap<>();
            parameters.put(0, new ServiceParameter(DTCParameterType.NUMERIC, "The first number"));
            parameters.put(1, new ServiceParameter(DTCParameterType.NUMERIC, "The second number"));
            return parameters;

    }
}
