package dtc.services;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class represents the SIN service which computes the trigonometric sine value
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class SinService extends Service {

    public SinService() {
        super("SIN", "Trigonometric sine function", new ServiceParameter(DTCParameterType.NUMERIC, "sine")); 
    }

    @Override
    public String process(ArrayList<String> parameters) throws NotEnoughParametersException, TooManyParametersException, InvalidParametersTypeException {
        switch (this.checkParametersType(parameters)) {
            case OK:
                break;

            case NOT_ENOUGH_PARAMETERS:
                throw new NotEnoughParametersException();

            case TOO_MANY_PARAMETERS:
                throw new TooManyParametersException();

            case INVALID_TYPE:
                throw new InvalidParametersTypeException();
        }

        double angleDegrees = Double.parseDouble(parameters.get(0));
        double angleRadians = Math.toRadians(angleDegrees);

        double result = Math.sin(angleRadians);

        return Double.toString(result);
    }

    @Override
    public HashMap<Integer, ServiceParameter> readParameters() {
        HashMap<Integer, ServiceParameter> parameters = new HashMap<>();
        parameters.put(0, new ServiceParameter(DTCParameterType.NUMERIC, "The angle in degrees"));

        return parameters;
    }
}
