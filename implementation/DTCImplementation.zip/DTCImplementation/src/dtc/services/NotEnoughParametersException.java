package dtc.services;

/**
 * This class represents the exception thrown when there a not enough parameters received
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class NotEnoughParametersException extends Exception {

    public NotEnoughParametersException() {
    }
    
}
