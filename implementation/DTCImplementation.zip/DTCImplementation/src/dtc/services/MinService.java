package dtc.services;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class represents the MIN service which can identify the minimum value in a given list of values
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class MinService extends Service {

    public MinService() {
        super("MIN", "Finds the minimum value", new ServiceParameter(DTCParameterType.NUMERIC, "The minimum value"));
    }

    @Override
    public String process(ArrayList<String> parameters) throws NotEnoughParametersException, TooManyParametersException, InvalidParametersTypeException {
        switch (this.checkParametersType(parameters)) {
            case OK:
                break;

            case NOT_ENOUGH_PARAMETERS:
                throw new NotEnoughParametersException();

            case TOO_MANY_PARAMETERS:
                throw new TooManyParametersException();

            case INVALID_TYPE:
                throw new InvalidParametersTypeException();
        }

        // We can safely cast
        if (parameters.size() >= 1) {
            // All values are in the first parameter, separated by spaces
            String[] values = parameters.get(0).split(" ");

            double minimum = Double.parseDouble(values[0]);

            for (int i = 1; i < values.length; ++i) {
                double current = Double.parseDouble(values[i]);

                if (current < minimum) {
                    minimum = current;
                }
            }

            return Double.toString(minimum);
        }

        // There's no value
        return "";
    }

    @Override
    public HashMap<Integer, ServiceParameter> readParameters() {
        HashMap<Integer, ServiceParameter> parameters = new HashMap<>();
        parameters.put(0, new ServiceParameter(DTCParameterType.LIST_NUMERIC, "All values to consider"));
        return parameters;
    }

}
