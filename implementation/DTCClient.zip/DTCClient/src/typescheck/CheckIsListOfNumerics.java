package typescheck;

/**
 * This class is used to check the supplied Type and verify it can be casted to a list of numerics
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class CheckIsListOfNumerics implements ICheckType {

    @Override
    public boolean isTypeCorrect(String valueToTest) {
        String[] allValues = valueToTest.split(" ");

        for (int i = 0; i < allValues.length; ++i)
        {
            if (!new CheckIsNumeric().isTypeCorrect(allValues[i]))
                return false;
        }
        
        return true;
    }
}
