package typescheck;

/**
 * This class is used to check the supplied Type and verify it can be casted to a numeric
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class CheckIsNumeric implements ICheckType {

    @Override
    public boolean isTypeCorrect(String valueToTest) {
        try {
            double d = Double.parseDouble(valueToTest);
        } catch (NumberFormatException ex) {
            return false;
        }
        
        return true;
    }
}
