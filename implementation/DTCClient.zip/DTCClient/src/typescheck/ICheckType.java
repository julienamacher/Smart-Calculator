package typescheck;

/**
 * This interface is implemented by all type checker classes
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public interface ICheckType {
    public boolean isTypeCorrect(String valueToTest);
}
