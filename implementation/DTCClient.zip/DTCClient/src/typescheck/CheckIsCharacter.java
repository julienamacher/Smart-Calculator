package typescheck;

/**
 * This class is used to check the supplied Type and verify it can be casted to a character
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class CheckIsCharacter implements ICheckType {

    @Override
    public boolean isTypeCorrect(String valueToTest) {
       return(valueToTest.length() == 1 && Character.isLetter(valueToTest.charAt(0)));
    }
}
