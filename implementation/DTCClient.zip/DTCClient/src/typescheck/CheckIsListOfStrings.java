package typescheck;

/**
 * This class is used to check the supplied Type and verify it can be casted to a list of Strings
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class CheckIsListOfStrings implements ICheckType {

    @Override
    public boolean isTypeCorrect(String valueToTest) {
        String[] allValues = valueToTest.split(" ");

        for (int i = 0; i < allValues.length; ++i)
        {
            int len = allValues[i].length();
            
            if (len < 2 || allValues[i].charAt(0) != '"' || allValues[i].charAt(len - 1) != '"')
                return false;
        }
        
        return true;
    }
}
