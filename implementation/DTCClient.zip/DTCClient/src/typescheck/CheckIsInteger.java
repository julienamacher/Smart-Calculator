package typescheck;

/**
 * This class is used to check the supplied Type and verify it can be casted to an integer
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class CheckIsInteger implements ICheckType {

    @Override
    public boolean isTypeCorrect(String valueToTest) {
        try {
            Integer.parseInt(valueToTest);
        } catch (NumberFormatException e) {
            return false;
        }

        return true;
    }
}
