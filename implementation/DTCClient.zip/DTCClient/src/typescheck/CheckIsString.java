package typescheck;

/**
 * This class is used to check the supplied Type and verify it can be casted to a String
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class CheckIsString implements ICheckType {

    @Override
    public boolean isTypeCorrect(String valueToTest) {
        return true;
    }
}
