package GUiControllers;

import dtc.protocol.messages.DTCServerResponse_ListServices;
import dtc.protocol.messages.Request;
import dtc.protocol.messages.ServerRequestHelper;
import dtc.protocol.messages.DTCServerResponse_Connect;
import GUI.UIWaitConnectAndGetMethods;
import dtc.services.DTCParameterType;
import dtc.protocol.impl.DTCProtocol;
import dtcclient.*;
import dtcclient.Client;
import dtcclient.Server;
import dtc.protocol.messages.ServerResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Controller_UIWaitConnectAndGetMethods extends GUIController {

    UIWaitConnectAndGetMethods gui;
    Server server;

    public void finalize() throws Throwable
    {
        super.finalize();
        
        Client client = this.getClient(server);
        
        if (client != null)
        {
            if (client.isRegistered(this))
                client.unregisterObserver(this);
        }
    }

    public Controller_UIWaitConnectAndGetMethods(HashMap<Server, Client> clients, Server server, String userId, String password) {
        super(clients);
        this.server = server;
        gui = new UIWaitConnectAndGetMethods(this, server);

        Client client = this.getClient(server);

        if (client == null)
            client = this.setClient(server);
        
        if (!client.isRegistered(this))
            client.registerObserver(this);

        try {
            if (!client.isConnected())
                client.connectToServer(server.GetHost(), DTCProtocol.DEFAULT_PORT);
            
            Request connect;

            if (server.IsAuthenticationRequired()) {
                connect = ServerRequestHelper.BuildRequest_ConnectWithCredentials(userId, password);
            } else {
                connect = ServerRequestHelper.BuildRequest_ConnectWithoutCredentials();
            }

            client.sendToServer(connect);

        } catch (IOException ex) {
            this.gui.cannotConnectToServer();
        }
    }

    @Override
    public void messageReceived(ServerResponse message) {
        if (message.getClass() == DTCServerResponse_Connect.class) {
            DTCServerResponse_Connect messageCasted = (DTCServerResponse_Connect) message;

            if (messageCasted.getStatus() == ServerResponse.STATUS.SUCCESS) {
                //JOptionPane.showMessageDialog(null, "Connection successful");

                 // Once authenticated or connected, we proceed to ask the available methods
                try {
                    Thread.sleep(500);
                } catch (InterruptedException ex) {
                }

                gui.setVisible(false);

                Request askForMethods = ServerRequestHelper.BuildRequest_ListingServices();

                this.getClient(server).sendToServer(askForMethods);
            } else {
                this.getClient(server).unregisterObserver(this);
                this.gui.showErrorLogin(messageCasted);

            }
        } else if (message.getClass() == DTCServerResponse_ListServices.class) {
            DTCServerResponse_ListServices messageCasted = (DTCServerResponse_ListServices) message;

            HashMap<String, Map<Integer, DTCParameterType>> methods = new HashMap<>();

            server.SetMethods(messageCasted.getServices());

            this.getClient(server).unregisterObserver(this);
            new Controller_UIListingMethods(clients, server);
        }
    }

    @Override
    public void windowClosed() {
        try {
            this.finalize();
        } catch (Throwable ex) {
        }
    }

}
