package GUiControllers;

import GUI.UIListingMethods;
import dtcclient.Client;
import dtc.protocol.messages.InvalidParametersOrderException;
import dtcclient.Server;
import dtc.protocol.messages.ServerResponse;
import dtc.protocol.impl.beaconing.ServersListener;
import dtc.services.ServiceConsumption;
import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;

public class Controller_UIListingMethods extends GUIController implements Observer {
    UIListingMethods gui;
    Server server;
    
    public Controller_UIListingMethods(HashMap<Server, Client> clients, Server server)
    {
        super(clients);
        this.server = server;
        this.gui = new UIListingMethods(this, server);
        this.addObserver(gui);
    }
    
    // Update from ServersListener
    @Override
    public void update(Observable o, Object arg) {
        if (o.getClass() == ServersListener.class)
        {
            this.setChanged();
            
            // We notify the GUI
            this.notifyObservers(arg);
        }
    }

    @Override
    public void messageReceived(ServerResponse message) {
        
    }

    public void userWantsToUseThisMethod(ServiceConsumption service) {
        try {
            new Controller_UIUseMethod(clients, server, service);
        } catch (InvalidParametersOrderException ex) {
        }
    }

    @Override
    public void windowClosed() {
        try {
            this.finalize();
        } catch (Throwable ex) {
        }
    }
}