package GUiControllers;

import GUI.UIUseMethod;
import dtcclient.Client;
import dtc.protocol.messages.DTCServerResponse_ConsumeService;
import dtc.protocol.messages.InvalidParametersOrderException;
import dtc.protocol.messages.Request;
import dtcclient.Server;
import dtc.protocol.messages.ServerRequestHelper;
import dtc.protocol.messages.ServerResponse;
import dtc.services.ServiceConsumption;
import java.util.HashMap;
import java.util.Map;

public class Controller_UIUseMethod extends GUIController {
    Server server;
    ServiceConsumption service;
    UIUseMethod gui;
    final HashMap<String, Map<Integer, String>> waitingForResult = new HashMap<>();

    public void finalize() throws Throwable
    {
        Client client = this.getClient(this.server);
        
        if (client != null)
        {
            if (client.isRegistered(this))
                client.unregisterObserver(this);
        }
    }
    
    public Controller_UIUseMethod(HashMap<Server, Client> clients, Server server, ServiceConsumption service) throws InvalidParametersOrderException {
        super(clients);
        this.server = server;
        this.service = service;
        
        gui = new UIUseMethod(this, service);
    }

    @Override
    public void messageReceived(ServerResponse message) {
        if (message.getClass() == DTCServerResponse_ConsumeService.class)
        {
            // Waiting for the answer
            
            DTCServerResponse_ConsumeService messageCasted = (DTCServerResponse_ConsumeService)message;
            
            synchronized(waitingForResult)
            {
                String nonce = messageCasted.getNonce();
                
                if (waitingForResult.containsKey(nonce))
                {
                    gui.calculationReceivedFromServer(messageCasted.getResult(), waitingForResult.get(nonce));
                    
                    waitingForResult.remove(nonce);
                }
            }
        }
    }

    public void submitQuery(ServiceConsumption service, Map<Integer, String> parameters) {
        
        Client client = this.getClient(this.server);
        
        if (client == null || !client.isConnected())
        {
            this.gui.showBeenDisconnected();
        }
        else
        {
            client.registerObserver(this);
            String nonce = ServerRequestHelper.GenerateNonce();

            synchronized (waitingForResult)
            {
                waitingForResult.put(nonce, parameters);
            }

            Request request = null;

            try {
                request = ServerRequestHelper.BuildRequest_ConsumeService(service.getServiceName(), parameters, nonce);
            } catch (InvalidParametersOrderException ex) {
            }

            client.sendToServer(request);
        }
    }

    @Override
    public void windowClosed() {
        try {
            this.finalize();
        } catch (Throwable ex) {
        }
    }
}
