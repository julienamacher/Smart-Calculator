package GUiControllers;

import GUI.UIListingServers;
import dtcclient.Client;
import dtc.protocol.impl.beaconing.DiscoveredServer;
import dtcclient.Server;
import dtc.protocol.messages.ServerResponse;
import dtc.protocol.impl.beaconing.ServersListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;

public class Controller_UIListingServers extends GUIController implements Observer {

    final UIListingServers gui;
    final ArrayList<DiscoveredServer> servers = new ArrayList<>();

    public Controller_UIListingServers(HashMap<Server, Client> clients) {
        super(clients);
        this.gui = UIListingServers.GetInstance(this);
        this.addObserver(gui);
    }

    // Update from ServersListener
    @Override
    public void update(Observable o, Object arg) {
        if (o.getClass() == ServersListener.class) {
            this.setChanged();

            servers.clear();

            Iterator<DiscoveredServer> it = ((HashSet<DiscoveredServer>)arg).iterator();
            while (it.hasNext()) {
                servers.add(it.next());
            }

            // We notify the GUI
            this.notifyObservers(arg);
        }
    }

    public void userWantsToConnectToServer(int index) {
        if (index >= 0 && index < servers.size()) {
            DiscoveredServer severClicked = servers.get(index);
            
            if (severClicked.IsAuthenticationRequired()) {
                new Controller_UIAskPassword(clients, servers.get(index));
            } else {
                new Controller_UIWaitConnectAndGetMethods(clients, servers.get(index), null, null);
            }

            // else : already connected
        }
    }

    @Override
    public void messageReceived(ServerResponse message) {
    }

    @Override
    public void windowClosed() {
        try {
            this.finalize();
        } catch (Throwable ex) {
        }
    }
}
