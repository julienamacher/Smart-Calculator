package GUiControllers;

import GUI.UIAskPassword;
import dtc.protocol.impl.DTCProtocol;
import dtcclient.Client;
import dtc.protocol.messages.DTCServerResponse_Registration;
import dtc.protocol.messages.Request;
import dtcclient.Server;
import dtc.protocol.messages.ServerRequestHelper;
import dtc.protocol.messages.ServerResponse;
import java.io.IOException;
import java.util.HashMap;

public class Controller_UIAskPassword extends GUIController {

    UIAskPassword gui;
    Server server;
    HashMap<String, String> waitingForResult = new HashMap<>();

    public Controller_UIAskPassword(HashMap<Server, Client> clients, Server server) {
        super(clients);
        this.gui = new UIAskPassword(this, server);
        this.server = server;
    }

    public void userProvidedCredentials(String userId, String password) {
        gui.setVisible(false);
        new Controller_UIWaitConnectAndGetMethods(clients, this.server, userId, password);
    }

    @Override
    public void messageReceived(ServerResponse message) {
         if (message.getClass() == DTCServerResponse_Registration.class)
         {
             DTCServerResponse_Registration messageCasted = (DTCServerResponse_Registration)message;
             
             String nonce = messageCasted.getNonce();
             String userIdCreated = null;
             
             synchronized (waitingForResult) {
                 if (waitingForResult.containsKey(nonce)) {
                     userIdCreated = waitingForResult.get(nonce);
                     waitingForResult.remove(nonce);
                 }
                 
                 if (waitingForResult.isEmpty())
                 {
                     this.getClient(server).unregisterObserver(this);
                 }
             }
             
             this.getClient(server).unregisterObserver(this);
             
             if (messageCasted.getStatus() == ServerResponse.STATUS.SUCCESS)
             {
                 this.gui.registrationSuccess(userIdCreated, messageCasted);
             }
             else
             {
                 this.gui.registrationError(userIdCreated, messageCasted);
             }
         }
    }

    public void userWantsToRegister(String userId, String password) throws IOException {
        Client client = this.getClient(server);
        
        if (client == null)
        {
            client = this.setClient(server);
            client.connectToServer(server.GetHost(), DTCProtocol.DEFAULT_PORT);
        }
        
        if (!client.isRegistered(this))
            client.registerObserver(this);
        
        String nonce = ServerRequestHelper.GenerateNonce();
        
        synchronized (waitingForResult)
        {
            waitingForResult.put(nonce, userId);
        }
        
        Request request = ServerRequestHelper.BuildRequest_Register(nonce, userId, password);
        
        client.sendToServer(request);
    }

    @Override
    public void windowClosed() {
        try {
            this.finalize();
        } catch (Throwable ex) {
        }
    }
}
