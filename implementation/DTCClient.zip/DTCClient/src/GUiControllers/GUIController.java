package GUiControllers;

import dtcclient.Client;
import dtcclient.IGeneralClientListener;
import dtcclient.Server;
import dtc.protocol.messages.ServerResponse;
import java.util.HashMap;
import java.util.Observable;

public abstract class GUIController extends Observable implements IGeneralClientListener {

    final HashMap<Server, Client> clients;

    public GUIController(HashMap<Server, Client> clients) {
        this.clients = clients;
    }

    public Client getClient(Server server) {

        synchronized (clients) {
            if (!clients.containsKey(server)) {
                return null;
            }

            return clients.get(server);
        }
    }

    public Client setClient(Server server) {
        
        Client client =  new Client();
        
        synchronized (clients) {

            if (clients.containsKey(server)) {
                return null;
            }

            clients.put(server, client);
        }
        
        return client;
    }

    @Override
    public abstract void messageReceived(ServerResponse message);
    
    public abstract void windowClosed();
}
