package nethelper;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.Reader;
import java.io.UnsupportedEncodingException;

/**
 * This class contains all low-level functions related to the network
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class NetHelper {

    /**
     * @param reader the stream to read from
     * @return contents of the low level message
     * @throws java.io.IOException in case the stream could not be read from
     */
    
    public static byte[] readUntilCRLF(Reader reader) throws IOException {
        ByteArrayOutputStream contentsByte = new ByteArrayOutputStream();
        int read;
        int lastRead = 0;

        while ((read = reader.read()) != -1) {
            if (read == 10 && lastRead == 13) {
                break; // complete line received
            } else if (lastRead == 13) {
                contentsByte.write(lastRead);
                contentsByte.write(read);
            } else if (read != 13) {
                contentsByte.write(read);
            }

            lastRead = read;
        }

        contentsByte.flush();
        return contentsByte.toByteArray();
    }
    
    /**
     * @param reader the stream to read from
     * @param encoding the encoding to use to decode the low level message into a String
     * @return contents of the low level message decoded in String
     * @throws UnsupportedEncodingException in case the supplied encoding is invalid
     */
    
    public static String readMessage(Reader reader, String encoding) throws UnsupportedEncodingException
    {
        boolean wasLastLineEmpty = false;
        ByteArrayOutputStream message = new ByteArrayOutputStream();
        
        while (true)
        {
            byte[] line;
            
            try {
                line = NetHelper.readUntilCRLF(reader);
                
                if (line.length == 0 && wasLastLineEmpty)
                    break;

                message.write(line);

                wasLastLineEmpty = (line.length == 0);
            } catch (IOException ex) {
            }
        }
        
        return new String(message.toByteArray(), encoding);
    }
}
