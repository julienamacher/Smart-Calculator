package GUI;

import javax.swing.UIManager;

public class GUIConfig {
    public static String LOOK_AND_FEEL = "Nimbus";
    
    public static void tryToApplyLookAndFeel()
    {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if (GUIConfig.LOOK_AND_FEEL.equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
        }
    }
}
