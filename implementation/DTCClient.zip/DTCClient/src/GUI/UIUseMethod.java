package GUI;

import GUiControllers.Controller_UIUseMethod;
import dtc.services.DTCParameterType;
import dtc.protocol.impl.DTCProtocol;
import dtc.protocol.impl.beaconing.DiscoveredServer;
import dtc.protocol.messages.InvalidParametersOrderException;
import dtc.services.ServiceConsumption;
import dtc.services.ServiceParameter;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;
import javax.swing.*;

public class UIUseMethod implements Observer {
    protected Controller_UIUseMethod controller;
    protected ServiceConsumption service;
    protected static UIUseMethod instance = null;

    protected JFrame frame = new JFrame("Use method");
    protected DefaultListModel listModel = new DefaultListModel();
    protected JScrollPane scroll;
    protected Map<Integer, DTCParameterType> parameters = null;
    protected ArrayList<InputValue> inputValues = new ArrayList<>();

    public void calculationReceivedFromServer(String result, Map<Integer, String> parameters) {
        
        StringBuilder sb = new StringBuilder();
        
        sb.append("Received result for :").append(System.lineSeparator());
        
        int parametersCount = parameters.size();
        for (int i = 0; i < parametersCount ; ++i)
        {
            sb.append("Parameter #").append(Integer.toString(i + 1)).append(" : ").append(parameters.get(i)).append(System.lineSeparator());
        }
        
        sb.append("Result : ").append(result);
        
        JOptionPane.showMessageDialog(this.frame, sb.toString(), "Computation result", JOptionPane.INFORMATION_MESSAGE);
    }

    public void showBeenDisconnected() {
        JOptionPane.showMessageDialog(this.frame, "You have been disconnected. Please reconnect.", "Disconnected", JOptionPane.INFORMATION_MESSAGE);
    }

    abstract class InputValue {

        final protected UIUseMethod parent;
        final protected DTCParameterType type;
        final protected int parameterNumber;

        public DTCParameterType getType() {
            return type;
        }

        public int getParameterNumber() {
            return parameterNumber;
        }

        public InputValue(UIUseMethod parent, DTCParameterType type, int parameterNumber) {
            this.parent = parent;
            this.type = type;
            this.parameterNumber = parameterNumber;
        }

        public abstract Object getValues();
        public abstract void paint(JPanel panel);
    }

    class AskForAList extends InputValue {

        final private JButton addToList = new JButton("Add");
        final private JButton clearList = new JButton("Clear");
        final private TextField input = new TextField(7);
        final private ArrayList<String> values = new ArrayList<>();
        
        final private DefaultListModel listModel = new DefaultListModel();  
        final private JList displayValues = new JList(listModel);
        final private JScrollPane scroll = new JScrollPane(displayValues);
        private JPanel parentFrame = null;

        public AskForAList(UIUseMethod parent, DTCParameterType type, int parameterNumber) {
            super(parent, type, parameterNumber);
            
            //scroll.setSize(new Dimension(100, 80));

            this.registerEvents();
            
            GUIConfig.tryToApplyLookAndFeel();
        }

        public void clearList() {
            this.values.clear();
        }

        public void registerEvents() {
            this.addToList.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                    String text = input.getText();

                    // WARNING
                    // Since this is a list parameter, we must check the submitted value
                    // against the primitive of the list. For example, if this is a List::integers,
                    // we have to check against integer.isValid(value) and not against List::integers.isValie(value)
                    if (AskForAList.super.type.getTypeCheckerPrimitive().isTypeCorrect(text)) {
                        values.add(text);
                        listModel.addElement(text);
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(parentFrame, "Invalid value");
                    }
                    
                    input.setText("");
                    input.requestFocus();
                }
            });

            this.clearList.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    values.clear();
                    listModel.removeAllElements();
                }
            });
        }

        @Override
        public Object getValues() {
            return this.values;
        }

        @Override
        public void paint(JPanel panel) {

            this.parentFrame = panel;
                    
            JPanel horizontal1 = new JPanel();
            horizontal1.setLayout(new FlowLayout(FlowLayout.LEFT));
            
            horizontal1.add(new JLabel(Integer.toString(this.parameterNumber + 1) + " : " + this.type.getDescription()));
            
            JPanel horizontal2 = new JPanel();
            horizontal2.setLayout(new FlowLayout(FlowLayout.LEFT));
            
            horizontal2.add(this.input);
            horizontal2.add(this.addToList);
            horizontal2.add(this.clearList);

            JPanel horizontal3 = new JPanel();
            horizontal3.setLayout(new FlowLayout(FlowLayout.LEFT));
            horizontal3.add(this.scroll);

            panel.add(horizontal1);
            panel.add(horizontal2);
            panel.add(horizontal3);
            
        }

    }

    class AskForASingleValue extends InputValue {

        final private TextField input = new TextField(7);
        
        public AskForASingleValue(UIUseMethod parent, DTCParameterType type, int parameterNumber) {
            super(parent, type, parameterNumber);
            
            GUIConfig.tryToApplyLookAndFeel();
        }

        @Override
        public Object getValues() {
            return this.input.getText();
        }

        @Override
        public void paint(JPanel panel) {
            JPanel horizontal1 = new JPanel();
            horizontal1.setLayout(new FlowLayout(FlowLayout.LEFT));
            
            horizontal1.add(new JLabel(Integer.toString(this.parameterNumber + 1) + " : " + this.type.getDescription()));

            JPanel horizontal2 = new JPanel();
            horizontal2.setLayout(new FlowLayout(FlowLayout.LEFT));
            
            horizontal2.add(this.input);
            
            panel.add(horizontal1);
            panel.add(horizontal2);
        }
    }

    public UIUseMethod(Controller_UIUseMethod controller, ServiceConsumption service) throws InvalidParametersOrderException {
        
        this.controller = controller;
        this.service = service;
        
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            }
        });

        JPanel vertical = new JPanel();
        vertical.setLayout(new BoxLayout(vertical, BoxLayout.Y_AXIS));
        Map<Integer, ServiceParameter> params = service.getParameters();
        int parametersCount = params.size();
        
        JPanel title1 = new JPanel();
        JLabel titleLabel = new JLabel("Method : " + this.service.getServiceName());
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        title1.add(titleLabel);
        
        JPanel title2 = new JPanel();
        JLabel descrLabel = new JLabel(this.service.getServiceDecription());
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        title2.add(descrLabel);

        
        for (int i = 0; i < parametersCount; ++i) {
            if (!params.containsKey(i)) {
                throw new InvalidParametersOrderException();
            }
            
            DTCParameterType parameter = params.get(i).getType();
            
            InputValue inputValue;

            if (parameter.isList()) {
                inputValue = new AskForAList(this, parameter, i);
            } else {
                inputValue = new AskForASingleValue(this, parameter, i);
            }
            

            inputValue.paint(vertical);
            inputValues.add(inputValue);
        }
        
        JPanel submitRegion = new JPanel();
        submitRegion.setLayout(new FlowLayout(FlowLayout.LEFT));
        
        JButton btnSubmit = new JButton("Submit request");
        
        btnSubmit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submitQuery();
            }
        });
        
        JPanel all = new JPanel();
        all.setLayout(new BoxLayout(all, BoxLayout.Y_AXIS));
        
        submitRegion.add(btnSubmit);
        
        all.add(title1);
        all.add(title2);
        all.add(vertical);
        all.add(submitRegion);
        
        frame.add(new JScrollPane(all));
        
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.LINE_AXIS));
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
    
    public void submitQuery()
    {
        StringBuilder sb = new StringBuilder();
        
        for (InputValue iv : inputValues)
        {
            if (iv.getClass() == AskForASingleValue.class)
            {
                String value = (String)((AskForASingleValue)iv).getValues();
                
                if (!iv.type.getTypeCheckerPrimitive().isTypeCorrect(value))
                {
                    sb.append("Parameter ").append(iv.parameterNumber + 1).append(" is invalid").append(System.lineSeparator());
                }
            }
        }
        
        if (sb.length() == 0)
        {
            // no input error so we can submit the query
            
            Map<Integer, String> parameters = new HashMap<>();
            
            for (InputValue iv : inputValues)
            {
               parameters.put(iv.getParameterNumber(), DTCProtocol.serializeDataType(iv.getType(), iv.getValues()) );
            }
            
            this.controller.submitQuery(this.service, parameters);
        }
        else
        {
            JOptionPane.showMessageDialog(this.frame, sb.toString().trim(), "Invalid input", JOptionPane.ERROR_MESSAGE);
        }
    }

    @Override
    public void update(Observable o, Object arg) {
        if (arg instanceof HashSet) {
            this.updateServers((HashSet<DiscoveredServer>) arg);
        }
    }

    public void updateServers(HashSet<DiscoveredServer> servers) {
        listModel.clear();

        Iterator<DiscoveredServer> it = servers.iterator();
        while (it.hasNext()) {
            DiscoveredServer current = it.next();
            listModel.addElement(current.GetHost() + " " + current.GetName() + " " + current.IsAuthenticationRequired());
        }
    }

}
