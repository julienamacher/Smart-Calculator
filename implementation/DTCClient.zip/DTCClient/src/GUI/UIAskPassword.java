package GUI;

import GUiControllers.Controller_UIAskPassword;
import dtc.protocol.messages.DTCServerResponse_Registration;
import dtcclient.Server;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.IOException;
import javax.swing.*;

public class UIAskPassword {

    protected Controller_UIAskPassword controller;
    protected Server server;
    protected JFrame frame = new JFrame("Authentication required");
    protected JLabel userIdLabel = new JLabel("User ID:");
    protected JLabel passwordLabel = new JLabel("Password:");
    protected TextField userId = new TextField(23);
    protected TextField password = new TextField(23);
    protected JButton btnContinue = new JButton("Continue");
    protected JButton btnRegistration = new JButton("Register");

    public UIAskPassword(Controller_UIAskPassword controller, Server server) {

        this.controller = controller;
        this.server = server;

        Container contentPane = frame.getContentPane();
        SpringLayout layout = new SpringLayout();
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        contentPane.setLayout(layout);

        btnContinue.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submitCredentials();
            }
        });

        btnRegistration.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submitRegistration();
            }
        });

        contentPane.add(userIdLabel);
        contentPane.add(userId);

        layout.putConstraint(SpringLayout.WEST, userIdLabel, 10, SpringLayout.WEST, contentPane);
        layout.putConstraint(SpringLayout.NORTH, userIdLabel, 25, SpringLayout.NORTH, contentPane);
        layout.putConstraint(SpringLayout.NORTH, userId, 25, SpringLayout.NORTH, contentPane);
        layout.putConstraint(SpringLayout.WEST, userId, 25, SpringLayout.EAST, userIdLabel);

        contentPane.add(passwordLabel);
        contentPane.add(password);

        layout.putConstraint(SpringLayout.WEST, passwordLabel, 10, SpringLayout.WEST, contentPane);
        layout.putConstraint(SpringLayout.NORTH, passwordLabel, 25, SpringLayout.NORTH, userId);
        layout.putConstraint(SpringLayout.NORTH, password, 25, SpringLayout.NORTH, userId);
        layout.putConstraint(SpringLayout.WEST, password, 25, SpringLayout.EAST, userIdLabel);

        contentPane.add(btnContinue);
        contentPane.add(btnRegistration);

        layout.putConstraint(SpringLayout.WEST, btnContinue, 0, SpringLayout.WEST, password);
        layout.putConstraint(SpringLayout.NORTH, btnContinue, 25, SpringLayout.NORTH, password);
        layout.putConstraint(SpringLayout.NORTH, btnRegistration, 25, SpringLayout.NORTH, password);
        layout.putConstraint(SpringLayout.WEST, btnRegistration, 25, SpringLayout.EAST, btnContinue);

        GUIConfig.tryToApplyLookAndFeel();

        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent winEv)
            {
                windowIsClosing();
            }
        });
        
        frame.setSize(300, 160);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
    
    public void windowIsClosing()
    {
        controller.windowClosed();
    }

    private void submitCredentials() {
        String userId = this.userId.getText();
        String password = this.password.getText();

        this.controller.userProvidedCredentials(userId, password);
    }

    private void submitRegistration() {
        String userId = this.userId.getText();
        String password = this.password.getText();

        try {
            this.controller.userWantsToRegister(userId, password);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this.frame, "Cannot connect to server.", "Connection error", JOptionPane.ERROR_MESSAGE);
            controller.windowClosed();
        }
    }

    public void setVisible(boolean b) {
        frame.setVisible(b);
    }

    public void registrationError(String userIdNotCreated, DTCServerResponse_Registration message) {
        
        String error;
        
        switch (message.getErrorCode())
        {
            case 1:
                error = "Server does not require authentication";
                break;
                
            case 2:
                error = "User id is invalid";
                break;
                
            case 3:
                error = "User id is too long or too short";
                break;
                
            case 4:
                error = "Password is too short";
                break;
                
            case 5:
                error = "Password is invalid";
                break;
                
            case 6:
                error = "User id is a duplicate";
                break;
                
            case 7:
                error = "Internal error";
                break;
                
            default:
                error = "Unknown error";
                break;
        }
        
        JOptionPane.showMessageDialog(this.frame, error, "Registration error", JOptionPane.ERROR_MESSAGE);
    }

    public void registrationSuccess(String userIdCreated, DTCServerResponse_Registration message) {
        JOptionPane.showMessageDialog(this.frame, "The account " + userIdCreated + " was created successfully", "Registration success", JOptionPane.INFORMATION_MESSAGE);
    }
}
