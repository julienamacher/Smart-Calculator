package GUI;

import GUiControllers.Controller_UIListingServers;
import dtc.protocol.impl.beaconing.DiscoveredServer;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import javax.swing.*;

public class UIListingServers implements Observer {

    protected Controller_UIListingServers controller;
    protected static UIListingServers instance = null;

    protected JFrame frame = new JFrame("Compute engines");
    protected JPanel all = new JPanel();
    protected JScrollPane scroller = new JScrollPane(all);
    
    protected UIListingServers(Controller_UIListingServers controller) {

        this.controller = controller;

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            }
        });

        GUIConfig.tryToApplyLookAndFeel();
        
        all.setLayout(new BoxLayout(all, BoxLayout.PAGE_AXIS));

        JLabel pleaseWait = new JLabel("Please wait, listening for servers ...");
        pleaseWait.setFont(new Font("Arial", Font.BOLD, 11));
        all.add(pleaseWait);

        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent winEv) {
                windowIsClosing();
            }
        });

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(380, 150);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public void windowIsClosing() {
        controller.windowClosed();
    }

    public void userWantsToConnectToServer(int serverIndex) {
        controller.userWantsToConnectToServer(serverIndex);
    }

    public static UIListingServers GetInstance(Controller_UIListingServers controller) {
        if (instance == null) {
            instance = new UIListingServers(controller);
        }

        return instance;
    }

    @Override
    public void update(Observable o, Object arg) {
        if (arg instanceof HashSet) {
            this.updateServers((HashSet<DiscoveredServer>) arg);
        }
    }

    public void updateServers(HashSet<DiscoveredServer> servers) {

        this.all.removeAll();
        frame.remove(this.all);

        if (!servers.isEmpty()) {
            JPanel title = new JPanel();
            title.setLayout(new FlowLayout(FlowLayout.LEFT));
            JLabel titleLabel = new JLabel("Select a server");
            titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
            title.add(titleLabel);
            
            all.add(title);
        }

        Iterator<DiscoveredServer> it = servers.iterator();
        for (int i = 0; it.hasNext(); ++i) {
            DiscoveredServer current = it.next();

            JLabel host = new JLabel(current.GetHost());
            JLabel name = new JLabel(current.GetName());
            name.setFont(new Font("Arial", Font.BOLD, 12));

            JLabel auth = new JLabel((current.IsAuthenticationRequired() ? "private" : "public"));
            JButton connect = new JButton("connect");

            connect.setName(Integer.toString(i));

            connect.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    userWantsToConnectToServer(Integer.parseInt(((JButton) e.getSource()).getName()));
                }
            });

            JPanel currentServer = new JPanel();
            currentServer.setLayout(new FlowLayout(FlowLayout.LEFT));

            currentServer.add(host);
            currentServer.add(name);
            currentServer.add(auth);
            currentServer.add(connect);

            all.add(currentServer);
        }

        frame.add(scroller);
        frame.validate();
        frame.repaint();
    }
}
