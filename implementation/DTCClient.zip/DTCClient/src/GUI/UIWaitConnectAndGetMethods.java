package GUI;

import GUiControllers.Controller_UIWaitConnectAndGetMethods;
import dtc.protocol.messages.DTCServerResponse_Connect;
import dtcclient.Server;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class UIWaitConnectAndGetMethods {
    protected Controller_UIWaitConnectAndGetMethods controller;
    protected Server server;
    protected JFrame frame = new JFrame("Authentication required");
    protected JButton btnCancel = new JButton("Cancel");
    
    public UIWaitConnectAndGetMethods(Controller_UIWaitConnectAndGetMethods controller, Server server) {
        
        this.controller = controller;
        this.server = server;
        
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        frame.add(new JLabel("Please wait while connecting and retrieving methods ..."));
        frame.add(btnCancel);
        
        GUIConfig.tryToApplyLookAndFeel();
        
        frame.setSize(360, 100);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public void setVisible(boolean b) {
        frame.setVisible(b);
    }

    public void cannotConnectToServer() {
        JOptionPane.showMessageDialog(this.frame, "Cannot connect to server.", "Connection"
                + " error", JOptionPane.ERROR_MESSAGE);
    }

    public void showErrorLogin(DTCServerResponse_Connect message) {
        
        String error;
        
        switch (message.getErrorCode())
        {
            case 1:
                error = "Please provide the credentials.";
                break;
                
            case 2:
                error = "This server does not require authentication.";
                break;
                
            case 3:
                error = "Authentication is disabled.";
                break;
                
            case 4:
                error = "Unknown user id.";
                break;
                
            case 5:
                error = "User id found, but the provided password is incorrect.";
                break;
                
            case 6:
                error = "Internal error.";
                break;
                
            default:
                error = "Unknown error.";
                break;
        }
        
        JOptionPane.showMessageDialog(this.frame, error, "Authentication failed", JOptionPane.ERROR_MESSAGE);
        this.setVisible(false);
    }
}
