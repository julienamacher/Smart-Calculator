package GUI;

import GUiControllers.Controller_UIListingMethods;
import dtcclient.Server;
import dtc.services.ServiceConsumption;
import dtc.services.ServiceParameter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;
import javax.swing.*;

public class UIListingMethods implements Observer {

    protected Server server;
    protected JFrame frame = new JFrame("Compute engines");
    protected final Controller_UIListingMethods controller;

    public UIListingMethods(Controller_UIListingMethods controller, Server server) {
        this.controller = controller;
        this.server = server;

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                updateMethods();
            }
        });

        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent winEv) {
                windowIsClosing();
            }
        });

        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setLayout(new FlowLayout(FlowLayout.LEFT));
        frame.setSize(260, 200);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        GUIConfig.tryToApplyLookAndFeel();
    }

    public void windowIsClosing() {
        controller.windowClosed();
    }

    @Override
    public void update(Observable o, Object arg) {
    }

    public void updateMethods() {
        final ArrayList<ServiceConsumption> methods = this.server.GetMethods();

        JPanel all = new JPanel();
        all.setLayout(new BoxLayout(all, BoxLayout.PAGE_AXIS));

        JPanel title = new JPanel();
        title.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel titleLabel = new JLabel("Methods on : " + this.server.GetName());
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        title.add(titleLabel);
        all.add(title);

        int methodNumber = 0;
        for (ServiceConsumption method : methods) {
            JPanel horizontal = new JPanel();
            horizontal.setLayout(new FlowLayout(FlowLayout.LEFT));

            String methodName = method.getServiceName();
            StringBuilder line = new StringBuilder();

            line.append(methodName);

            for (Map.Entry<Integer, ServiceParameter> parameter : method.getParameters().entrySet()) {
                String parameterType = parameter.getValue().getType().getName();

                line.append(parameterType);
                line.append(" ");
            }

            JPanel firstLine = new JPanel();
            firstLine.setLayout(new FlowLayout(FlowLayout.LEFT));

            JLabel name = new JLabel(methodName);
            firstLine.add(name);

            JPanel secondLine = new JPanel();
            secondLine.setLayout(new FlowLayout(FlowLayout.LEFT));

            JLabel description = new JLabel(method.getServiceDecription());
            secondLine.add(description);

            JPanel thirdLine = new JPanel();
            thirdLine.setLayout(new FlowLayout(FlowLayout.LEFT));

            int paramCount = method.getParameters().size();

            JLabel parametersCount = new JLabel("(" + Integer.toString(paramCount) + " parameter" + (paramCount > 1 ? "s" : "") + ")");
            thirdLine.add(parametersCount);

            JPanel fourthLine = new JPanel();
            fourthLine.setLayout(new FlowLayout(FlowLayout.LEFT));

            JButton use = new JButton("Use");
            use.setName(Integer.toString(methodNumber));
            fourthLine.add(use);

            use.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int methodNumber = Integer.parseInt(((JButton) e.getSource()).getName());
                    controller.userWantsToUseThisMethod(methods.get(methodNumber));
                }
            });

            horizontal.add(firstLine);
            horizontal.add(secondLine);
            horizontal.add(thirdLine);
            horizontal.add(fourthLine);

            all.add(horizontal);

            ++methodNumber;
        }

        frame.add(all);

        frame.pack();
    }
}
