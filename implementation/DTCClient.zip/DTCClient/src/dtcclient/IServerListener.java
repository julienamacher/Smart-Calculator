package dtcclient;

import dtc.protocol.messages.DTCServerResponse_ListServices;
import dtc.protocol.messages.DTCServerResponse_Registration;
import dtc.protocol.messages.DTCServerResponse_Connect;
import dtc.protocol.messages.DTCServerResponse_ConsumeService;


/**
 * This interface is implemented by all DTC clients
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public interface IServerListener {
    public void onConnectionLost();
    public void onConnectResponse(DTCServerResponse_Connect message);
    public void onRegistrationResponse(DTCServerResponse_Registration message);
    public void onConsumeServiceResponse(DTCServerResponse_ConsumeService message);
    public void onListingServicesResponse(DTCServerResponse_ListServices message);
}
