package dtcclient;


import dtc.protocol.impl.beaconing.ServersListener;
import GUiControllers.Controller_UIListingServers;
import dtc.protocol.impl.DTCProtocol;
import java.util.HashMap;

public class DTCClient {

    public static void main(String[] args) {
        DTCClient m = new DTCClient();
        m.mainNonStatic();
    }
    
    public void mainNonStatic()
    {
        HashMap<Server, Client> clients = new HashMap<>();
        
        ServersListener listener = new ServersListener(DTCProtocol.BEACON_PORT, 30);
        
        Controller_UIListingServers listingServersController = new Controller_UIListingServers(clients);
        listener.addObserver(listingServersController);
    }
}
