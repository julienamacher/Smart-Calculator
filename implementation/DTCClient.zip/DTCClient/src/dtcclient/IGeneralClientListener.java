package dtcclient;

import dtc.protocol.messages.ServerResponse;

/**
 * This interface is implemented by all DTC clients who wished to subscribe to high
 * level network DTC messages
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public interface IGeneralClientListener {
    public void messageReceived(ServerResponse message);
}
