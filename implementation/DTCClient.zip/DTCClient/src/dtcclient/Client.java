package dtcclient;

import dtc.protocol.messages.DTCServerResponse_ListServices;
import dtc.protocol.messages.DTCServerResponse_Registration;
import dtc.protocol.messages.InvalidMessageFormatException;
import dtc.protocol.messages.Request;
import dtc.protocol.messages.DuplicateParametersIndexException;
import dtc.protocol.messages.ServerResponse;
import dtc.protocol.messages.DTCServerResponse_Connect;
import dtc.protocol.messages.DTCServerResponse_ConsumeService;
import dtc.messages.DTCMessageHelper;
import dtc.messages.DTCMessageNode;
import dtc.protocol.impl.DTCProtocol;
import dtc.protocol.impl.MalformedHierarchyForXMLFormat;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.w3c.dom.Document;
import xmlhelper.XMLHelper;

/**
 * This class is an implementation of a DTC client
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class Client implements IServerListener {

    HashSet<IGeneralClientListener> observers = new HashSet<>();
    final int timeout = 3000;
    Socket server = null;
    BufferedReader in;
    BufferedWriter out;
    Thread readFromServer;

    public boolean isRegistered(IGeneralClientListener controller) {
        synchronized (this.observers) {
            return this.observers.contains(controller);
        }
    }

    public void unregisterObserver(IGeneralClientListener observer) {
        synchronized (this.observers) {
            if (this.observers.contains(observer)) {
                this.observers.remove(observer);
            }
        }
    }

    public void registerObserver(IGeneralClientListener observer) {
        synchronized (this.observers) {
            this.observers.add(observer);
        }
    }

    public void connectToServer(String ip, int port) throws IOException {
        if (isConnected()) {
            this.disconnect();
        }

        InetSocketAddress endPoint = new InetSocketAddress(ip, port);

        this.server = new Socket();
        this.server.connect(endPoint, this.timeout);

        if (this.server.isConnected()) {
            // TO-DO
        }

        in = new BufferedReader(new InputStreamReader(this.server.getInputStream()));
        out = new BufferedWriter(new OutputStreamWriter(this.server.getOutputStream()));

        this.readFromServer = new Thread(new Runnable() {
            @Override
            public void run() {
                readFromServer();
            }
        });

        this.readFromServer.start();
    }

    public boolean isConnected() {
        return (this.server != null && this.server.isConnected());
    }

    public void disconnect() {
        if (this.isConnected()) {
            try {
                this.server.close();
                this.server = null;
                this.in.close();
                this.out.close();
            } catch (IOException ex) {
                Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void sendToServer(Request message) {
        DTCProtocol.sendMessage(out, message);
    }

    private void readFromServer() {

        while (true) {
            try {
                String incomingMessage = DTCProtocol.readMessage(in);

                if (incomingMessage.isEmpty()) {
                    this.disconnect();
                    return;
                }

                Document xmlDoc = null;
                DTCMessageNode messageDTC;

                try {
                    xmlDoc = XMLHelper.parseXMLFromString(incomingMessage);
                } catch (Exception ex) {
                    this.disconnect();
                    return;
                }

                messageDTC = DTCMessageHelper.XMLDocumentToDTCMessage(DTCProtocol.MessageType.MESSAGE_TYPE_RESULT, xmlDoc);

                switch (messageDTC.GetAttribute("type")) {
                    case "connect": {
                        DTCServerResponse_Connect message = DTCServerResponse_Connect.Parse(messageDTC);

                        this.notifyMessageReceived(message);
                        this.onConnectResponse(message);

                    }
                    break;

                    case "registration": {
                        DTCServerResponse_Registration message = DTCServerResponse_Registration.Parse(messageDTC);

                        this.notifyMessageReceived(message);
                        this.onRegistrationResponse(message);

                    }
                    break;

                    case "listServices": {
                        DTCServerResponse_ListServices message = DTCServerResponse_ListServices.Parse(messageDTC);

                        this.notifyMessageReceived(message);
                        this.onListingServicesResponse(message);

                    }
                    break;

                    case "consumeService": {
                        DTCServerResponse_ConsumeService message = DTCServerResponse_ConsumeService.Parse(messageDTC);

                        this.notifyMessageReceived(message);
                        this.onConsumeServiceResponse(message);

                    }
                    break;
                }

            } catch (UnsupportedEncodingException ex) {
                Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            } catch (DuplicateParametersIndexException ex) {
                Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InvalidMessageFormatException ex) {
                Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            } catch (MalformedHierarchyForXMLFormat ex) {
                Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void notifyMessageReceived(final ServerResponse response) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                synchronized (observers) {
                    for (IGeneralClientListener observer : observers) {
                        observer.messageReceived(response);
                    }
                }
            }

        }).start();

    }

    @Override
    public void onConnectionLost() {

    }

    @Override
    public void onConnectResponse(DTCServerResponse_Connect message) {

    }

    @Override
    public void onRegistrationResponse(DTCServerResponse_Registration message) {

    }

    @Override
    public void onConsumeServiceResponse(DTCServerResponse_ConsumeService message) {

    }

    @Override
    public void onListingServicesResponse(DTCServerResponse_ListServices message) {

    }

}
