package dtcclient;

import dtc.protocol.impl.beaconing.DiscoveredServer;
import dtc.services.ServiceConsumption;
import java.util.ArrayList;

/**
 * This class describes a server
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class Server {
    protected String host;
    protected String name;
    protected boolean requiresAuthentication;
    
    public Server(DiscoveredServer server)
    {
        this.host = server.GetHost();
        this.name = server.GetName();
        this.requiresAuthentication = server.IsAuthenticationRequired();
    }

    protected ArrayList<ServiceConsumption> methods = null;
    
    public Server(String host, String name, boolean requiresAuthentication) {
        this.host = host;
        this.name = name;
        this.requiresAuthentication = requiresAuthentication;
    }
    
    public ArrayList<ServiceConsumption> GetMethods()
    {
        return this.methods;
    }
    
    // TO-DO: set a copy
    public void SetMethods(ArrayList<ServiceConsumption> methods)
    {
        this.methods = methods;
    }
    
    public String GetHost()
    {
        return this.host;
    }
    
    public String GetName()
    {
        return this.name;
    }
    
    public boolean IsAuthenticationRequired()
    {
        return this.requiresAuthentication;
    }
}
