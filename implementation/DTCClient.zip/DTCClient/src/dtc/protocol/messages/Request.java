package dtc.protocol.messages;

import dtc.messages.DTCMessageNode;

/**
 * This class represents a network request
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class Request
{
    final DTCMessageNode root;
    
    public Request(DTCMessageNode root)
    {
        this.root = root;
    }
    
    public DTCMessageNode GetRoot()
    {
        return this.root;
    }
}
