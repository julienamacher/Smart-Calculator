package dtc.protocol.messages;

/**
 * This class represents the exception thrown when the received parameters are not in the correct order
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class InvalidParametersOrderException extends Exception {
}
