package dtc.protocol.messages;

/**
 * This class represents the exception thrown when an invalid message is received
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class InvalidMessageFormatException extends Exception {
}
