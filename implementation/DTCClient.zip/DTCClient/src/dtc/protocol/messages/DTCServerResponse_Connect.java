package dtc.protocol.messages;

import dtc.messages.DTCMessageNode;

/**
 * This class represents a response to a connect message
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class DTCServerResponse_Connect extends ServerResponse {

    final int errorCode;
    STATE state;

    public int getErrorCode() {
        return errorCode;
    }

    enum STATE {

        CONNECTED, AUTHENTICATED, CONNECTION_ERROR, AUTHENTICATION_ERROR
    }

    public enum ERROR_CODES {

        SERVER_DOES_NOT_REQUIRE_AUTHENTICATION,
        USER_ID_OR_PASSWORD_MISSING,
        AUTHENTICATION_DISABLED,
        UNKNOWN_USER_ID,
        INVALID_PASSWORD,
        INTERNAL_ERROR
    }

    public static DTCServerResponse_Connect Parse(DTCMessageNode response) throws InvalidMessageFormatException {
        STATE state;
        ServerResponse.Parse(response, "connect");
        final DTCMessageNode resultNode = response.GetNodeByName("result");

        switch (resultNode.GetNodeValue()) {
            case "authenticated":
                state = STATE.AUTHENTICATED;
                break;

            case "connected":
                state = STATE.CONNECTED;
                break;

            case "connection_error":
                state = STATE.CONNECTION_ERROR;
                break;

            case "authentication_error":
                state = STATE.AUTHENTICATION_ERROR;
                break;
                
            default:
                throw new InvalidMessageFormatException();
        }

        final ServerResponse.STATUS status = (state == STATE.AUTHENTICATED || state == STATE.CONNECTED) ? ServerResponse.STATUS.SUCCESS : ServerResponse.STATUS.ERROR;
        int errorCode = 0;

        if (status != ServerResponse.STATUS.SUCCESS) {
            errorCode = Integer.valueOf(response.GetNodeByName("error").GetNodeByName("code").GetNodeValue());
        }

        return new DTCServerResponse_Connect(status, state, errorCode);
    }

    private DTCServerResponse_Connect(ServerResponse.STATUS status, STATE state, int errorCode) {
        super("connect", status);
        this.state = state;
        this.errorCode = errorCode;
    }
}
