package dtc.protocol.messages;

import dtc.messages.DTCMessageNode;

/**
 * This class represents an asynchronous request
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class AsyncRequest extends Request
{
    private final String nonce;
    
    public AsyncRequest(DTCMessageNode root, String nonce)
    {
        super(root);
        this.nonce = nonce;
    }
    
    public String GetNonce()
    {
        return this.nonce;
    }
}
