package dtc.protocol.messages;

import dtc.services.ServiceConsumption;
import dtc.services.ServiceParameter;
import dtc.messages.DTCMessageNode;
import dtc.services.DTCParameterType;
import dtc.protocol.impl.DTCProtocol;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * This class represents a response to a list services message
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class DTCServerResponse_ListServices extends ServerResponse {

    ArrayList<ServiceConsumption> services;
    int errorCode;

    enum ERROR_CODES {

        SERVER_DOES_NOT_REQUIRE_AUTHENTICATION,
        USER_ID_TOO_LONG_OR_TOO_SHORT,
        EMAIL_IS_A_DUPLICATE,
        EMAIL_IS_INVALID,
        PASSWORD_IS_TOO_SHORT
    }

    public ArrayList<ServiceConsumption> getServices() {
        return services;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public static DTCServerResponse_ListServices Parse(DTCMessageNode response) throws InvalidMessageFormatException, DuplicateParametersIndexException {
        ServerResponse.Parse(response, "listServices");
        final DTCMessageNode resultNode = response.GetNodeByName("result");
        final ServerResponse.STATUS status = resultNode.GetAttribute("success").equals("true") ? ServerResponse.STATUS.SUCCESS : ServerResponse.STATUS.ERROR;
        int errorCode = 0;

        ArrayList<ServiceConsumption> services = new ArrayList<>();

        if (status != ServerResponse.STATUS.SUCCESS) {
            errorCode = Integer.valueOf(resultNode.GetNodeByName("error").GetNodeByName("code").GetNodeValue());
        } else {

            DTCMessageNode allServicesNode = resultNode.GetChildren().get(0);
            
            for (DTCMessageNode currentService : allServicesNode.GetChildren()) {
                
                Map<Integer, ServiceParameter> parameters = new HashMap<>();

                String currentServiceName = currentService.GetNodeByName("name").GetNodeValue();
                String currentServiceDescription = currentService.GetNodeByName("description").GetNodeValue();

                DTCMessageNode currentServiceParameters = currentService.GetNodeByName("parameters");
                ArrayList<DTCMessageNode> children = currentServiceParameters.GetChildren();

                Iterator<DTCMessageNode> itParameters = children.iterator();

                final int parametersSize = children.size();
                for (int p = 0; p < parametersSize; ++p) {
                    DTCMessageNode currentParameter = (DTCMessageNode) itParameters.next();

                    int parameterOrder = Integer.parseInt(currentParameter.GetAttribute("order"));

                    if (parameterOrder < 1) {
                        throw new InvalidMessageFormatException();
                    }

                    DTCParameterType parameterType = DTCProtocol.GetTypeByName(currentParameter.GetNodeByName("type").GetNodeValue());
                    String parameterDescription = currentParameter.GetNodeByName("description").GetNodeValue();

                    if (parameters.containsKey(parameterOrder - 1)) {
                        throw new DuplicateParametersIndexException();
                    }

                    parameters.put(parameterOrder - 1, new ServiceParameter(parameterType, parameterDescription));
                }

                DTCMessageNode returnsNode = currentService.GetNodeByName("returns");
                String returnsWhat = returnsNode.GetNodeByName("type").GetNodeValue();

                DTCParameterType returnsType = DTCProtocol.GetTypeByName(returnsWhat);

                String returnsDescr = returnsNode.GetNodeByName("description").GetNodeValue();

                services.add(new ServiceConsumption(currentServiceName, currentServiceDescription, new ServiceParameter(returnsType, returnsDescr), returnsDescr, parameters));
            }
        }

        return new DTCServerResponse_ListServices(status, errorCode, services);
    }

    private DTCServerResponse_ListServices(ServerResponse.STATUS status, int errorCode, ArrayList<ServiceConsumption> services) {
        super("listServices", status);
        this.errorCode = errorCode;
        this.services = services;
    }
}
