package dtc.protocol.messages;

/**
 * This class represents the exception thrown when there are multiple parameters having the same index
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class DuplicateParametersIndexException extends Exception {
}
