package dtc.protocol.messages;

/**
 * This class represents an asynchronous response
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public abstract class AsyncServerResponse extends ServerResponse {
    protected final String nonce;

    public String getNonce() {
        return nonce;
    }
    
    public AsyncServerResponse(String messageType, String nonce, ServerResponse.STATUS status)
    {
        super(messageType, status);
        this.nonce = nonce;
    }
}
