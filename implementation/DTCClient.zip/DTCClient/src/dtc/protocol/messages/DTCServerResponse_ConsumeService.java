package dtc.protocol.messages;

import dtc.messages.DTCMessageNode;

/**
 * This class represents a response to a service consume message
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class DTCServerResponse_ConsumeService extends ServerResponse {

    final int errorCode;
    private final String nonce;
    private final String result;

    enum ERROR_CODES {

        AUTHENTICATION_IS_REQUIRED,
        INVALID_SERVICE_NAME,
        SERVICE_IS_UNAVAILABLE,
        ARGUMENTS_MISSING,
        TOO_MANY_ARGUMENTS_PROVIDED,
        INVALID_PARAMETERS_TYPE
    }

    public String getNonce() {
        return nonce;
    }

    public String getResult() {
        return result;
    }

    public static DTCServerResponse_ConsumeService Parse(DTCMessageNode response) throws InvalidMessageFormatException, DuplicateParametersIndexException {
        ServerResponse.Parse(response, "consumeService");
        final String no = response.GetNodeByName("nonce").GetNodeValue();
        final DTCMessageNode resultNode = response.GetNodeByName("result");
        final ServerResponse.STATUS status = resultNode.GetAttribute("success").equals("true") ? ServerResponse.STATUS.SUCCESS : ServerResponse.STATUS.ERROR;
        int errorCode = 0;
        String res = null;

        if (status != ServerResponse.STATUS.SUCCESS) {
            errorCode = Integer.valueOf(resultNode.GetNodeByName("error").GetNodeByName("code").GetNodeValue());
        } else {
            res = resultNode.GetNodeByName("value").GetNodeValue();
        }

        return new DTCServerResponse_ConsumeService(status, errorCode, no, res);
    }

    private DTCServerResponse_ConsumeService(ServerResponse.STATUS status, int errorCode, String nonce, String result) {
        super("consumeService", status);
        this.errorCode = errorCode;
        this.nonce = nonce;
        this.result = result;
    }
}
