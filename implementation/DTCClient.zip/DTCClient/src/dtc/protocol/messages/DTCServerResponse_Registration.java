package dtc.protocol.messages;

import dtc.messages.DTCMessageNode;

/**
 * This class represents a response to a registration message
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class DTCServerResponse_Registration extends AsyncServerResponse {

    final int errorCode;

    public int getErrorCode() {
        return errorCode;
    }

    public enum ERROR_CODES {

        SERVER_DOES_NOT_REQUIRE_AUTHENTICATION,
        USER_ID_INVALID,
        USER_ID_TOO_LONG_OR_TOO_SHORT,
        PASSWORD_IS_TOO_SHORT,
        PASSWORD_INVALID,
        USER_EXISTS,
        INTERNAL_ERROR
    }

    public static DTCServerResponse_Registration Parse(DTCMessageNode response) throws InvalidMessageFormatException {
        ServerResponse.Parse(response, "registration");
        final String nonce = response.GetNodeByName("nonce").GetNodeValue();
        final DTCMessageNode resultNode = response.GetNodeByName("result");
        final ServerResponse.STATUS status = resultNode.GetAttribute("type").equals("success") ? ServerResponse.STATUS.SUCCESS : ServerResponse.STATUS.ERROR;
        int errorCode = 0;

        if (status != ServerResponse.STATUS.SUCCESS) {
            errorCode = Integer.valueOf(resultNode.GetNodeByName("error").GetNodeByName("code").GetNodeValue());
        }

        return new DTCServerResponse_Registration(nonce, status, errorCode);
    }

    private DTCServerResponse_Registration(String nonce, ServerResponse.STATUS status, int errorCode) {
        super("registration", nonce, status);
        this.errorCode = errorCode;
    }

}
