package dtc.protocol.messages;

import dtc.messages.DTCMessageNode;
import java.util.Map;
import java.util.Random;

/**
 * This class represents all helper functions used to create high level request messages to be sent to the server
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class ServerRequestHelper
{
    static Random random = new Random();
    final static int NONCE_LENGTH = 12;
    
    public static String GenerateNonce()
    {
        final char[] pick = "abcdefghijklmnopqrstuvwxyz1234567890".toCharArray();
        final StringBuilder sb = new StringBuilder();
        
        for (int i = 0; i < NONCE_LENGTH; ++i) {
            sb.append(pick[random.nextInt(pick.length)]);
        }
        
        return sb.toString().toUpperCase();
    }
    
    public static Request BuildRequest_ListingServices()
    {
        DTCMessageNode request = new DTCMessageNode("request");
        request.AddAttribute("type", "listServices");
        request.AddAttribute("protocol", "1.0");
        
        return new Request(request);
    }
    
    public static AsyncRequest BuildRequest_ConsumeService(String serviceName, Map<Integer, String> parameters, String nonce)
            throws InvalidParametersOrderException
    {
        DTCMessageNode request = new DTCMessageNode("request");
        request.AddAttribute("type", "consumeService");
        request.AddAttribute("protocol", "1.0");
        
        DTCMessageNode nonceNode = new DTCMessageNode("nonce");
        nonceNode.SetNodeValue(nonce);
        
        DTCMessageNode nameNode = new DTCMessageNode("name");
        nameNode.SetNodeValue(serviceName);
        
        DTCMessageNode serviceParameters = new DTCMessageNode("parameters");

        final int parametersSize = parameters.size();
        
        for (int i = 0 ; i < parametersSize ; ++i)
        {
            if (!parameters.containsKey(i)) {
                throw new InvalidParametersOrderException();
            }

            DTCMessageNode currentParameter = new DTCMessageNode("parameter");
            currentParameter.AddAttribute("order", Integer.toString(i + 1));
            currentParameter.AddChild(new DTCMessageNode("value", parameters.get(i)));
            
            serviceParameters.AddChild(currentParameter);
        }
        
        request.AddChild(nonceNode);
        request.AddChild(nameNode);
        request.AddChild(serviceParameters);
        
        return new AsyncRequest(request, nonce);
    }
    
    public static AsyncRequest BuildRequest_Register(final String nonce,
                                                     final String userID,
                                                     final String password)
    {
        DTCMessageNode request = new DTCMessageNode("request");
        request.AddAttribute("type", "registration");
        request.AddAttribute("protocol", "1.0");
        
        DTCMessageNode nonceNode = new DTCMessageNode("nonce");
        DTCMessageNode userIdNode = new DTCMessageNode("user_id");
        DTCMessageNode passwordNode = new DTCMessageNode("password");
        
        nonceNode.SetNodeValue(nonce);
        userIdNode.SetNodeValue(userID);
        passwordNode.SetNodeValue(password);
        
        request.AddChild(nonceNode);
        request.AddChild(userIdNode);
        request.AddChild(passwordNode);
        
        return new AsyncRequest(request, nonce);
    }
    
    public static Request BuildRequest_ConnectWithCredentials(final String userID,
                                                              final String password)
    {
        DTCMessageNode request = new DTCMessageNode("request");
        request.AddAttribute("type", "connect");
        request.AddAttribute("protocol", "1.0");
        
        DTCMessageNode userNode = new DTCMessageNode("user_id");
        DTCMessageNode passwordNode = new DTCMessageNode("password");
        DTCMessageNode credentialsNode = new DTCMessageNode("credentials");
        
        userNode.SetNodeValue(userID);
        passwordNode.SetNodeValue(password);

        credentialsNode.AddChild(userNode);
        credentialsNode.AddChild(passwordNode);
        request.AddChild(credentialsNode);
        

        return new Request(request);
    }
    
    public static Request BuildRequest_ConnectWithoutCredentials()
    {
        DTCMessageNode request = new DTCMessageNode("request");
        request.AddAttribute("type", "connect");
        request.AddAttribute("protocol", "1.0");
        
        return new Request(request);
    }
}
