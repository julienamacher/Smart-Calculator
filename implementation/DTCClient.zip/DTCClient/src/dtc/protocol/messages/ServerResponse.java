package dtc.protocol.messages;

import dtc.messages.DTCMessageNode;

/**
 * This class represents a server response
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public abstract class ServerResponse {
    public enum STATUS { SUCCESS, ERROR };
    final protected STATUS status;
    final protected String messageType;

    public STATUS getStatus() {
        return status;
    }

    public String getMessageType() {
        return messageType;
    }
    
    public ServerResponse(final String messageType, STATUS status)
    {
        this.messageType = messageType;
        this.status = status;
    }
    
    public static boolean CheckResponseType(DTCMessageNode response, String messageTypeCompareTo)
    {
        return response.GetNodeName().equals("response") &&
               response.AttributeExists("type") &&
               response.GetAttribute("type").equals(messageTypeCompareTo);
    }
    
    public static ServerResponse Parse(DTCMessageNode response, String messageTypeCompareTo) throws InvalidMessageFormatException
    {
        if (!ServerResponse.CheckResponseType(response, messageTypeCompareTo))
        {
            throw new InvalidMessageFormatException();
        }

        return null;
    }
}
