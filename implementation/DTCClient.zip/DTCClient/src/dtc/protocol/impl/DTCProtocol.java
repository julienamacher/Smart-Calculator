package dtc.protocol.impl;

import dtc.services.DTCParameterType;
import ch.heigvd.res.toolkit.interfaces.IEventType;
import ch.heigvd.res.toolkit.interfaces.IMessageType;
import ch.heigvd.res.toolkit.interfaces.IState;
import dtc.messages.DTCMessageHelper;
import dtc.messages.DTCMessageNode;
import dtc.protocol.messages.Request;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import javax.xml.transform.TransformerException;
import nethelper.NetHelper;
import org.w3c.dom.Document;
import xmlhelper.XMLHelper;

/**
 * This class is used to define constants, enum types, and network methods specific to the DTC Protocol
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */
public class DTCProtocol {

    /**
     * The default TCP port on which the server is accepting connection requests
     */
    public final static int DEFAULT_PORT = 10871;
    public final static int BEACON_PORT = 10870;

    private static void sendMessage(Writer writer, String str) {
        try {
            writer.write(str.trim());
            writer.write("\r\n");
            writer.write("\r\n");
            writer.flush();
        } catch (IOException ex) {
        }
    }

    public static String readMessage(Reader reader) throws IOException {
        ByteArrayOutputStream binaryMessage = new ByteArrayOutputStream();

        // Reading until two lines empty are encountered (=end of message)
        while (true) {
            byte[] contents = NetHelper.readUntilCRLF(reader);

            // New message received
            if (contents.length == 0) {
                break;
            }

            binaryMessage.write(contents);
            binaryMessage.write("\r\n".getBytes("UTF-8"));
        }

        // Getting the text representation of the message
        String message = new String(binaryMessage.toByteArray(), "UTF-8").trim();

        return message;
    }

    public static void sendMessage(Writer writer, Request messageToSend) {
        DTCMessageNode message = messageToSend.GetRoot();
        Document messageXML = null;
        
        try
        {
            messageXML = DTCMessageHelper.DTCMessageToXMLDocument(DTCProtocol.MessageType.MESSAGE_TYPE_COMMAND, message);
        }
        catch (MalformedHierarchyForXMLFormat ex)
        {
        }
        
        String messageText = null;
        try {
            messageText = XMLHelper.prettyPrintXML(messageXML, "UTF-8");
        } catch (TransformerException ex) {
        }

        DTCProtocol.sendMessage(writer, messageText);
    }
    
    public static String serializeDataType(DTCParameterType type, Object values)
    {
        if (type.isList())
        {
            ArrayList<String> valuesCasted = (ArrayList<String>)values;
            
            if (!valuesCasted.isEmpty())
            {
                StringBuilder sb = new StringBuilder();
                
                for (String value : valuesCasted)
                {
                    if (type == DTCParameterType.LIST_STRING)
                        sb.append('"');

                    sb.append(value);

                    if (type == DTCParameterType.LIST_STRING)
                        sb.append('"');
                    
                    sb.append(' ');
                }
                
                String ret = sb.toString();
                return ret.substring(0, ret.length() - 1);
            }
            
            return "";
        }
        else
        {
            return (String)values;
        }
    }

    public static DTCParameterType GetTypeByName(String name) {
        switch (name) {
            case "numeric":
                return DTCParameterType.NUMERIC;

            case "integer":
                return DTCParameterType.INTEGER;

            case "character":
                return DTCParameterType.CHARACTER;

            case "string":
                return DTCParameterType.STRING;

            case "list_numeric":
            case "list<numeric>":
                return DTCParameterType.LIST_NUMERIC;

            case "list_integer":
            case "list<integer>":
                return DTCParameterType.LIST_INTEGER;

            case "list_character":
            case "list<character>":
                return DTCParameterType.LIST_CHARACTER;

            case "list_string":
            case "list<string>":
                return DTCParameterType.LIST_STRING;
        }

        return null;
    }
    
    
    /**
     * The maximum inactivity period, after which a notification will be sent to
     * the client
     */
    public final static long MAX_INACTIVE_TIMEOUT = 120000;

    /**
     * This enum type defines the possible states for the Ping Pong prococol
     * state machine
     */
    public enum State implements IState {

        STATE_START,
        STATE_NORMAL,
        STATE_END;
    }

    /**
     * This enum type defines the specific event types understood by the Ping
     * Pong protocol state machine. Note that there is another, generic enum
     * type defined in ch.heigvd.res.toolkit.impl.EventType
     */
    public enum EventType implements IEventType {

        EVENT_TYPE_MAX_IDLE_TIME_REACHED;
    }

    public enum MessageType implements IMessageType {

        MESSAGE_TYPE_COMMAND,
        MESSAGE_TYPE_RESULT,
        MESSAGE_TYPE_NOTIFICATION
    }

}
