package dtc.protocol.impl.beaconing;

import dtcclient.Server;
import java.util.Date;

/**
 * This class represents a server which was discovered by broadcast
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public final class DiscoveredServer extends Server {

    protected Date lastBeaconReceived;

    public DiscoveredServer(String host, String name, boolean requiresAuthentication) {
        super(host, name, requiresAuthentication);
        this.ReceivedBeacon();
    }

    public void ReceivedBeacon() {
        this.lastBeaconReceived = new Date();
    }

    public Date GetLastBeacon() {
        return this.lastBeaconReceived;
    }

    @Override
    public int hashCode() {
        int hash = 1;
        hash = hash * 17 + this.host.hashCode();
        hash = hash * 31 + this.name.hashCode();
        hash = hash * 13 + (this.requiresAuthentication ? 1 : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }

        if (obj == this) {
            return true;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        DiscoveredServer other = (DiscoveredServer) obj;

        return (this.host.equals(other.host)
                && this.name.equals(other.name)
                && this.requiresAuthentication == other.requiresAuthentication);
    }
}
