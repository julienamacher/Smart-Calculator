package dtc.protocol.impl.beaconing;

import dtc.messages.DTCMessageHelper;
import dtc.messages.DTCMessageNode;
import dtc.protocol.impl.*;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Observable;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.w3c.dom.Document;
import xmlhelper.XMLHelper;

/**
 * This class represents an active object used to listen for heartbeat broadcasts sent by servers
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class ServersListener extends Observable {

    protected final int port;
    protected final int removeNoBeaconInterval;
    protected volatile boolean runThreads = true;
    protected final HashSet<DiscoveredServer> servers = new HashSet<>();

    // removeNoBeaconInterval in seconds
    public ServersListener(final int port, final int removeNoBeaconInterval) {
        this.port = port;
        this.removeNoBeaconInterval = removeNoBeaconInterval;

        // First thread is listening for beacons
        new Thread(new Runnable() {
            @Override
            public void run() {
                startListening(port, 65536);
            }
        }).start();

        // Second thread is constantly removing old discovered servers
        new Thread(new Runnable() {
            @Override
            public void run() {
                removeTimedOutServers(removeNoBeaconInterval);
            }
        }).start();
    }

    private void removeTimedOutServers(final int removeNoBeaconInterval) {
        while (this.runThreads) {
            try {
                Thread.sleep(removeNoBeaconInterval * 1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(ServersListener.class.getName()).log(Level.SEVERE, null, ex);
            }

            synchronized (this.servers) {
                if (!this.servers.isEmpty()) {
                    Iterator<DiscoveredServer> it = this.servers.iterator();
                    boolean collectionHasChanged = false;

                    while (it.hasNext()) {
                        DiscoveredServer current = it.next();
                        Date lastBeaconReceivedFromThisServer = current.GetLastBeacon();

                        if (new Date().getTime() - lastBeaconReceivedFromThisServer.getTime() > removeNoBeaconInterval) {
                            it.remove();
                            collectionHasChanged = true;
                        }
                    }

                    // Notify listeners in case servers been removed
                    if (collectionHasChanged) {
                        this.setChanged();
                        this.notifyObservers(this.servers);
                    }
                }
            }
        }
    }

    public HashSet<DiscoveredServer> GetServers() {
        return this.servers;
    }

    private void startListening(final int portReceive, final int bufferSize) {
        byte[] bufferReceive = new byte[bufferSize];

        DatagramSocket serverSocket = null;
        DatagramPacket receivePacket;

        try {
            serverSocket = new DatagramSocket(portReceive);
        } catch (SocketException ex) {
        }

        while (this.runThreads) {
            receivePacket = new DatagramPacket(bufferReceive, bufferReceive.length);

            try {
                serverSocket.receive(receivePacket);
            } catch (IOException ex) {
            }

            byte[] actualData = Arrays.copyOf(receivePacket.getData(), receivePacket.getLength());
            String received = null;

            try {
                received = new String(actualData, "UTF-8");
            } catch (UnsupportedEncodingException ex) {
            }

            Document document = null;

            try {
                document = XMLHelper.parseXMLFromString(received);
            } catch (Exception ex) {
                Logger.getLogger(ServersListener.class.getName()).log(Level.SEVERE, null, ex);
                continue;
            }

            DTCMessageNode tree = null;

            try {
                tree = DTCMessageHelper.XMLDocumentToDTCMessage(DTCProtocol.MessageType.MESSAGE_TYPE_RESULT, document);
            } catch (MalformedHierarchyForXMLFormat ex) {
                Logger.getLogger(ServersListener.class.getName()).log(Level.SEVERE, null, ex);
                continue;
            }

            DTCMessageNode requiresAuthNode = tree.GetNodeByName("require_authentication");
            DTCMessageNode nameNode = tree.GetNodeByName("name");

            if (requiresAuthNode != null
                    && nameNode != null) {
                // Hostname is the machine that sent the UDP packet
                String hostName = receivePacket.getAddress().getHostAddress();
                String serverName = nameNode.GetNodeValue();
                boolean requiresAuthentication = (requiresAuthNode.GetNodeValue().equals("true"));

                DiscoveredServer discovered = new DiscoveredServer(hostName, serverName, requiresAuthentication);

                synchronized (this.servers) {
                    if (!this.servers.contains(discovered)) {
                        this.servers.add(discovered);

                        this.setChanged();
                        this.notifyObservers(this.servers);
                    }
                }
            }

        }
    }

}
