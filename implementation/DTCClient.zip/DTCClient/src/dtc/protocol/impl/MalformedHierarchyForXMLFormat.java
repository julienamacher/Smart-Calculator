package dtc.protocol.impl;

/**
 * This class represents the exception thrown when trying to XML parse an invalid XML document
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */


public class MalformedHierarchyForXMLFormat extends Exception {

    public MalformedHierarchyForXMLFormat() {
    }
    
}
