package dtc.services;

/**
 * This class describes a parameter passed to a service
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */
public class ServiceParameter {

    private final DTCParameterType type;
    private final String description;

    public ServiceParameter(DTCParameterType type, String description) {
        this.type = type;
        this.description = description;
    }

    public DTCParameterType getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }
}

