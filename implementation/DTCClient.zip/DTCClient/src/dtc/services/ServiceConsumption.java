package dtc.services;

import java.util.Map;

/**
 * This class represents a consumption of a service
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class ServiceConsumption {
    protected String serviceName;
    protected String serviceDecription;
    protected ServiceParameter returns;
    protected String returnsDescription;
    protected Map<Integer, ServiceParameter> parameters;

    public ServiceConsumption(String serviceName, String serviceDecription, ServiceParameter returns, String returnsDescription, Map<Integer, ServiceParameter> parameters) {
        this.serviceName = serviceName;
        this.serviceDecription = serviceDecription;
        this.returns = returns;
        this.returnsDescription = returnsDescription;
        this.parameters = parameters;
    }

    public String getServiceName() {
        return serviceName;
    }

    public String getServiceDecription() {
        return serviceDecription;
    }

    public String getReturnsDescription() {
        return returnsDescription;
    }

    public ServiceParameter getReturns() {
        return returns;
    }

    public Map<Integer, ServiceParameter> getParameters() {
        return parameters;
    }

}
