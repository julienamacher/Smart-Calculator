package dtc.services;

import typescheck.CheckIsListOfCharacters;
import typescheck.CheckIsInteger;
import typescheck.ICheckType;
import typescheck.CheckIsNumeric;
import typescheck.CheckIsString;
import typescheck.CheckIsListOfNumerics;
import typescheck.CheckIsListOfIntegers;
import typescheck.CheckIsListOfStrings;
import typescheck.CheckIsCharacter;

/**
 * This class represents all data types supported by the protocol
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public enum DTCParameterType {
    
    NUMERIC("NUMERIC", "Numeric", false, null, new CheckIsNumeric()),
    INTEGER("INTEGER", "Integer", false, null, new CheckIsInteger()),
    CHARACTER("CHARACTER", "Character", false, null, new CheckIsCharacter()),
    STRING("STRING", "String", false, null, new CheckIsString()),
    LIST_NUMERIC("LIST_NUMERIC", "List of Numerics", true, new CheckIsListOfNumerics(), new CheckIsNumeric()),
    LIST_INTEGER("LIST_INTEGER", "List of Integers", true, new CheckIsListOfIntegers(), new CheckIsInteger()),
    LIST_CHARACTER("LIST_CHARACTER", "Liste of Characters", true, new CheckIsListOfCharacters(), new CheckIsCharacter()),
    LIST_STRING("LIST_STRING", "List of Strings", true, new CheckIsListOfStrings(), new CheckIsString());
    
    private final String name;
    private final String description;
    private final boolean isList;
    private final ICheckType typeCheckerList;
    private final ICheckType typeCheckerPrimitive;

    public String getDescription() {
        return description;
    }

    public String getName() {
        return name;
    }

    public boolean isList() {
        return isList;
    }
    public ICheckType getTypeCheckerList() {
        return typeCheckerList;
    }

    public ICheckType getTypeCheckerPrimitive() {
        return typeCheckerPrimitive;
    }
    
    DTCParameterType(String name, String description, boolean isList, ICheckType typeCheckerList, ICheckType typeCheckerPrimitive) {
        this.name = name;
        this.description = description;
        this.isList = isList;
        this.typeCheckerList = typeCheckerList;
        this.typeCheckerPrimitive = typeCheckerPrimitive;
    }
}
