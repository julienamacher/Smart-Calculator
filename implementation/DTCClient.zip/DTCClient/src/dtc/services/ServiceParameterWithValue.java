package dtc.services;

/**
 * This class represents a single parameter passed to a computation Service
 *
 * @author Julien Amacher
 * @author Pierre-Alain Curty
 */

public class ServiceParameterWithValue extends ServiceParameter {
    protected Object value;
    
    public ServiceParameterWithValue(DTCParameterType type, String description, Object value) {
        super(type, description);
        this.value = value;
    }
    
    public Object GetValue()
    {
        return this.value;
    }
}
