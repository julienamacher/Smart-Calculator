package dtc.messages;

import ch.heigvd.res.toolkit.interfaces.IMessageType;
import dtc.protocol.impl.DTCProtocol;
import dtc.protocol.impl.MalformedHierarchyForXMLFormat;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

/**
 * This class contains all helper functions related to DTC nodes
 *
 * @author Julien Amacher
 */

public class DTCMessageHelper {

    public static Element DTCMessageToXMLTree(Document document, DTCMessageNode node)
    {
        Element current = document.createElement(node.GetNodeName());
        
        for (Map.Entry pairs : node.GetAttributes().entrySet()) {
            current.setAttribute((String)pairs.getKey(), (String)pairs.getValue());
        }
        
        String value = node.GetNodeValue();
        
        if (value == null)
        {
            ArrayList<DTCMessageNode> children = node.GetChildren();
            for (DTCMessageNode child : children)
            {
                current.appendChild(DTCMessageHelper.DTCMessageToXMLTree(document, child));
            }
        }
        else
        {
            Text textNode = document.createTextNode("");
            textNode.appendData(value);
            current.appendChild(textNode);
        }
        
        String c = current.getTextContent();
        return current;
    }
    
    public static String FormatXMLDocument(Document doc)
    {
        Transformer transformer = null;

        try {
            transformer = TransformerFactory.newInstance().newTransformer();
        } catch (TransformerConfigurationException ex) {
        }

        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        StreamResult result = new StreamResult(new StringWriter());
        DOMSource source = new DOMSource(doc);
        try {
            transformer.transform(source, result);
        } catch (TransformerException ex) {
        }
        return result.getWriter().toString();
    }
    
    public static DTCMessageNode XMLElementToDTCMessage(Element element) throws MalformedHierarchyForXMLFormat
    {
        NodeList nodes = element.getChildNodes();
        DTCMessageNode messageNode = new DTCMessageNode(element.getNodeName());
        
        boolean hasChild = false;
        
        for (int i = 0; i < nodes.getLength(); i++) {
            if (nodes.item(i).getNodeType() == Node.ELEMENT_NODE) {
                hasChild = true;
                messageNode.AddChild(DTCMessageHelper.XMLElementToDTCMessage((Element)nodes.item(i)));
            }
        }
        
        if (!hasChild)
        {
            messageNode.SetNodeValue(element.getTextContent());
        }
        
        NamedNodeMap attributes = element.getAttributes();
        
        for (int i = 0; i < attributes.getLength(); ++i)
        {
            Node attr = attributes.item(i);
            messageNode.AddAttribute(attr.getNodeName(), attr.getNodeValue());
        }
        
        return messageNode;
    }
    
    public static DTCMessageNode XMLDocumentToDTCMessage(IMessageType direction, Document xmlDoc) throws MalformedHierarchyForXMLFormat
    {
        NodeList nodes = xmlDoc.getChildNodes();
        
        int numberOfelementNodes = 0;
        Element rootNode = null;
        
        for (int i = 0; i < nodes.getLength() || numberOfelementNodes > 1; i++) {
            if (nodes.item(i).getNodeType() == Node.ELEMENT_NODE) {
                ++numberOfelementNodes;
                rootNode = (Element)nodes.item(i);
            }
        }
        
        if (numberOfelementNodes != 1)
            throw new MalformedHierarchyForXMLFormat();
        
        if ((direction == DTCProtocol.MessageType.MESSAGE_TYPE_COMMAND && !(((Element)rootNode).getNodeName().equals("request"))) ||
                (direction == DTCProtocol.MessageType.MESSAGE_TYPE_RESULT && !(((Element)rootNode).getNodeName().equals("response"))))
        {
            throw new MalformedHierarchyForXMLFormat();
        }
            
        DTCMessageNode tree = DTCMessageHelper.XMLElementToDTCMessage(rootNode);
        
        return tree;
    }
    
    public static Document DTCMessageToXMLDocument(IMessageType direction, DTCMessageNode message) throws MalformedHierarchyForXMLFormat
    {
        // XML must have a single root node
        if (message == null)
            throw new NullPointerException();
        
        if ((direction == DTCProtocol.MessageType.MESSAGE_TYPE_COMMAND && !message.GetNodeName().equals("request")) ||
                (direction == DTCProtocol.MessageType.MESSAGE_TYPE_RESULT && !message.GetNodeName().equals("response")))
        {
            throw new MalformedHierarchyForXMLFormat();
        }
        
        DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder domBuilder = null;
        
        try {
            domBuilder = domFactory.newDocumentBuilder();
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(DTCMessageHelper.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        Document document = domBuilder.newDocument();
        document.setXmlStandalone(true);
        document.appendChild(DTCMessageHelper.DTCMessageToXMLTree(document, message));
        
        return document;
    }
}
