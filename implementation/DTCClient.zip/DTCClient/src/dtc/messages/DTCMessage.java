package dtc.messages;

import ch.heigvd.res.toolkit.impl.Message;
import ch.heigvd.res.toolkit.interfaces.IMessageType;
import dtc.protocol.impl.MalformedHierarchyForXMLFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This class represents a DTC high-level message
 *
 * @author Julien Amacher
 */

public class DTCMessage extends Message {

    final static Logger LOG = Logger.getLogger(Message.class.getName());

    public DTCMessage(IMessageType type, DTCMessageNode tree) {
        this(type);
        this.setAttribute("tree", tree);
    }

    public DTCMessage(IMessageType type) {
        super(type);
    }
    
    public boolean AttributeExists(String name)
    {
        return this.attributes.containsKey(name);
    }

    @Override
    public String toString() {
        try {
            return DTCMessageHelper.FormatXMLDocument(DTCMessageHelper.DTCMessageToXMLDocument(this.type, (DTCMessageNode)this.getAttribute("tree")));
        } catch (MalformedHierarchyForXMLFormat ex) {
            Logger.getLogger(DTCMessage.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return null;
    }
}
