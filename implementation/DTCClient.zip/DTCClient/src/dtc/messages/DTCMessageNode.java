package dtc.messages;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class represents a DTC node
 *
 * @author Julien Amacher
 */

public class DTCMessageNode {
    
    private String nodeName;
    private String nodeValue = null;
    private HashMap<String, String> attributes = new HashMap<>();
    private ArrayList<DTCMessageNode> children = new ArrayList<>();
    
    public DTCMessageNode(String nodeName)
    {
        this.nodeName = nodeName;
    }
    
    public DTCMessageNode(String nodeName, String nodeValue)
    {
        this(nodeName);
        this.nodeValue = nodeValue;
    }
    
    public DTCMessageNode(String nodeName,
                               HashMap<String, String> attributes,
                               ArrayList<DTCMessageNode> children)
    {
        this.nodeName = nodeName;
        this.attributes = attributes;
        this.children = children;
        
        if (!this.children.isEmpty())
            this.nodeValue = null;
    }
    
    public String GetNodeName()
    {
        return this.nodeName;
    }
    
    public void SetNodeName(String nodeName)
    {
        this.nodeName = nodeName;
    }
    
    public String GetNodeValue()
    {
        return this.nodeValue;
    }
    
    public void SetNodeValue(String nodeValue)
    {
        this.nodeValue = nodeValue;
        
        if (this.nodeValue != null)
            this.children.clear();
    }
    
    public void AddAttribute(String name, String value)
    {
        this.attributes.put(name, value);
    }
    
    public DTCMessageNode GetNodeByName(String name)
    {
        DTCMessageNode node = null;
        
        for (DTCMessageNode n : this.children)
        {
            if (n.GetNodeName().equals(name))
            {
                node = n;
                break;
            }
        }
          
        return node;
    }
    
    // TO-DO: return copy
    public HashMap<String, String> GetAttributes()
    {
        return this.attributes;
    }
    
    public String GetAttribute(String name)
    {
        return this.attributes.get(name);
    }
    
    public ArrayList<DTCMessageNode> GetChildren()
    {
        return this.children;
    }
    
    public void AddChild(DTCMessageNode child)
    {
        this.children.add(child);
        this.nodeValue = null;
    }

    public boolean AttributeExists(String type) {
        return this.attributes.containsKey(type);
    }
}
